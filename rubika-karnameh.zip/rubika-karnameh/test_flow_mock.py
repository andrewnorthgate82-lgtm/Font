#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
test_flow_mock.py — تست خودکارِ منطق اسکریپت «بدون نیاز به مرورگر و روبیکا»
================================================================================
با شبیه‌سازی رفتار صفحه‌ی وب روبیکا (کلاس‌های ساختگی)، منطقِ
«جستجوی مخاطب ← باز کردن گفتگو ← پیوست تصویر ← ارسال» را آزمایش می‌کند.

اجرا:   python test_flow_mock.py
خروجی سالم یعنی منطق اسکریپت سالم است؛ فقط سلکتورهای واقعی صفحه‌ی روبیکا
باید روی سیستم شما با اسکریپت اصلی (و در صورت نیاز --inspect) بررسی شود.
"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import send_web as sw


# ---------------------------------------------------------------- شبیه‌ساز صفحه

class El:
    """یک عنصر DOM ساختگی"""

    def __init__(self, tag, text="", attrs=None):
        self.tag, self.text, self.attrs = tag, text, attrs or {}
        self.visible = True

    def click(self):
        self._click()

    def fill(self, v):
        self._fill(v)

    def press(self, key):
        self._press(key)

    def type(self, text, delay=None):
        self._type(text)

    press_sequentially = type


class MockPage:
    """رفتار شبیه روبیکا وب: جستجو ← نتیجه‌ها ← باز شدن چت ← پیوست ← ارسال"""

    def __init__(self, contacts):
        self.contacts = contacts  # {نام مخاطب در نتیجه جستجو: نام در هدر چت}
        self.state = "main"
        self.search_text = ""
        self.chat_with = None
        self.composer_value = ""
        self.attached_file = None
        self.sent = []  # (فایل، کپشن)
        self.no_send_button = False
        self.attach_evidence = True  # آیا پیوست، نشانه‌ای در صفحه می‌گذارد؟
        self.attach_modal = False    # رفتار جدید روبیکا: بعد از پیوست، پنجره‌ی «فایل انتخاب شده» باز می‌شود
        self.modal_open = False
        self.modal_caption = ""

    # ---------------- ساخت عناصر ----------------
    def _search_box(self):
        el = El("input", self.search_text)
        el._click = lambda: None
        el._fill = lambda v: setattr(self, "search_text", v)
        el._type = lambda t: setattr(self, "search_text", t)
        el._press = lambda k: None
        return el

    def _composer(self):
        el = El("textarea", self.composer_value)
        el._click = lambda: None
        el._fill = lambda v: setattr(self, "composer_value", v)

        def _type(t):
            self.composer_value = (self.composer_value or "") + t

        el._type = _type
        el._press = lambda k: self._send() if self.attached_file else None
        return el

    def _send(self):
        assert self.attached_file, "ارسال بدون فایل؟"
        self.sent.append((self.attached_file, self.composer_value))
        self.attached_file, self.composer_value = None, ""

    # ---------------- پنجره‌ی «فایل انتخاب شده» (مثل روبیکا وب) ----------------
    def _modal_send(self):
        assert self.attached_file, "ارسال از پنجره بدون فایل؟"
        self.sent.append((self.attached_file, self.modal_caption))
        self.attached_file, self.modal_caption = None, ""
        self.modal_open = False

    def _modal_input_el(self):
        el = El("input", "")
        el._click = lambda: None
        el._fill = lambda v: setattr(self, "modal_caption", v)

        def _type(t):
            self.modal_caption = (self.modal_caption or "") + t

        el._type = _type
        el._press = lambda k: self._modal_send() if k == "Enter" else None
        return el

    # ---------------- رابط playwright ----------------
    def locator(self, sel):
        s = sel.lower()
        if "فایل انتخاب شده" in sel:  # پنجره‌ی پیوست روبیکا
            if not self.modal_open:
                return _Single(None)
            # توجه: سلکتور ورودی هم عبارت button را (در شرطِ ظرف) دارد؛ پس اول
            # ورودی با بخش مخصوصِ خودش شناخته می‌شود، بعد دکمه‌ی ارسال.
            if "input[not(@type='file')]" in sel or "//textarea" in sel \
                    or "contenteditable" in sel:
                return _Single(self._modal_input_el())
            if "button" in sel:
                el = El("button", "ارسال")
                el._click = self._modal_send
                return _Single(el)
            return _Single(El("div", "۱ فایل انتخاب شده"))
        if "placeholder*='جستجو'" in sel and self.state == "main":
            return _Single(self._search_box())
        if ("پیام" in sel or "contenteditable" in sel or s == "textarea") and self.state == "chat_open":
            return _Single(self._composer())
        if ("title" in s or "name" in s or sel in ("h1", "h2")) and self.state == "chat_open":
            return _Single(El("h2", self.contacts[self.chat_with]))
        if ("ارسال" in sel or "send" in s) and self.state == "chat_open" \
                and self.attached_file and not self.no_send_button:
            el = El("button")
            el._click = self._send
            return _Single(el)
        if "result" in s or "option" in s or sel.startswith("li"):
            if self.state == "main" and self.search_text:
                q = sw.flat(self.search_text)
                return _List(self, [c for c in self.contacts if q in sw.flat(c)])
            return _List(self, [])
        if sel == "input[type='file']" and self.state == "chat_open":
            return _FileInputs(self)
        return _Single(None)

    def wait_for_timeout(self, ms):
        pass

    def evaluate(self, js, arg=None):
        if "input[type=file]" in js:  # find_attach_input_index
            return 0 if self.state == "chat_open" else -1
        if "canvas" in js and "imgs" in js:  # attachment_signature
            return {"imgs": 1 if (self.attached_file and self.attach_evidence) else 0, "prev": 0}
        raise AssertionError(f"page.evaluate غیرمنتظره: {js[:60]}")

    def screenshot(self, **kw):
        pass


class _Single:
    def __init__(self, el):
        self.el = el

    @property
    def first(self):
        return self

    def nth(self, i):
        return self if i == 0 else _Single(None)

    def count(self):
        return 1 if self.el else 0

    def is_visible(self):
        return bool(self.el) and self.el.visible

    def inner_text(self, timeout=None):
        return self.el.text if self.el else ""

    def click(self):
        self.el.click()

    def fill(self, v):
        self.el.fill(v)

    def press(self, key):
        self.el.press(key)

    def press_sequentially(self, text, delay=None):
        self.el.type(text)

    def type(self, text, delay=None):
        self.el.type(text)

    def get_attribute(self, name):
        return self.el.attrs.get(name) if self.el else None

    def input_value(self):
        return self.el.text if self.el else ""

    def evaluate(self, js):
        if "tagName" in js:
            return self.el.tag
        return self.el.text or ""


class _List:
    def __init__(self, page, names):
        self.page, self.names = page, names

    def count(self):
        return len(self.names)

    def nth(self, i):
        page, name = self.page, self.names[i]

        def open_chat():
            page.state = "chat_open"
            page.chat_with = name
            page.search_text = ""

        return _ResultItem(name, open_chat)


class _ResultItem:
    def __init__(self, name, click_fn):
        self.name, self._click = name, click_fn

    def is_visible(self):
        return True

    def inner_text(self, timeout=None):
        return self.name + "\n«آخرین پیام…»"

    def click(self):
        self._click()


class _FileInputs:
    def __init__(self, page):
        self.page = page

    def count(self):
        return 1 if self.page.state == "chat_open" else 0

    def nth(self, i):
        page = self.page

        class _FI:
            def get_attribute(self, name):
                return "image/*" if name == "accept" else None

            def set_input_files(self, path):
                page.attached_file = path
                if getattr(page, "attach_modal", False):
                    page.modal_open = True
                    page.modal_caption = ""

        return _FI()


class _PhoneList:
    """نتیجه‌های جستجوی شماره: متنِ نتیجه شامل شماره است"""

    def __init__(self, page, phones):
        self.page, self.phones = page, phones

    def count(self):
        return len(self.phones)

    def nth(self, i):
        page, ph = self.page, self.phones[i]

        def open_chat():
            page.state = "chat_open"
            page.chat_with = ph
            page.search_text = ""

        return _ResultItem(f"{page.contacts[ph]} — {ph}", open_chat)


class MockPagePhone(MockPage):
    """مثل روبیکا واقعی وقتی شماره را جستجو می‌کنیم: نتیجه شامل شماره است"""

    def __init__(self, phone_headers):  # {شماره: نام هدر چت}
        self.numbers = phone_headers
        super().__init__(dict(phone_headers))  # chat_with=شماره → هدر

    def locator(self, sel):
        s = sel.lower()
        if "placeholder*='جستجو'" in sel and self.state == "main":
            return _Single(self._search_box())
        if ("پیام" in sel or "contenteditable" in sel or s == "textarea") and self.state == "chat_open":
            return _Single(self._composer())
        if ("ارسال" in sel or "send" in s) and self.state == "chat_open" and self.attached_file:
            el = El("button")
            el._click = self._send
            return _Single(el)
        if "result" in s or "option" in s or sel.startswith("li"):
            if self.state == "main" and self.search_text:
                d = sw.digits_only(self.search_text)
                tail = d[-10:] if len(d) >= 10 else d
                hits = [ph for ph in self.numbers if sw.phone_tail(ph) == tail]
                return _PhoneList(self, hits)
            return _List(self, [])
        if sel == "input[type='file']" and self.state == "chat_open":
            return _FileInputs(self)
        return _Single(None)


# ---------------------------------------------------------------- سناریوها

CONTACTS = {
    "مسئول نسرا آران و بیدگل": "مسئول نسرا آران و بیدگل",
    "فرمانده گردان آران و بیدگل": "فرمانده گردان آران و بیدگل",
    "مسئول فضای مجازی آران و بیدگل": "مسئول فضای مجازی آران و بیدگل",
}

S = dict(sw.DEFAULT_SELECTORS)
CFG = {"verify_chat_title": True}

_tmp = Path(tempfile.mkdtemp(prefix="karnameh_test_"))
IMG = _tmp / "کارنامه_آران و بیدگل.png"
IMG.write_bytes(b"fake-image-data")


def test_open_chat_success():
    page = MockPage(CONTACTS)
    ok, err = sw.open_chat(page, "مسئول نسرا آران و بیدگل", S, CFG)
    assert ok, f"باز کردن چت ناموفق: {err}"
    assert page.chat_with == "مسئول نسرا آران و بیدگل"
    print("✅ open_chat: جستجو ← انتخاب نتیجه ← باز شدن چت (با تأیید عنوان)")


def test_open_chat_not_found():
    page = MockPage(CONTACTS)
    ok, err = sw.open_chat(page, "مسئول نسرا تهران", S, CFG)
    assert not ok, "باید ناموفق می‌شد!"
    assert "پیدا نشد" in err
    print("✅ open_chat: مخاطبِ ناموجود ← خطا، بدون باز شدن چت اشتباه")


def test_send_image():
    page = MockPage(CONTACTS)
    ok, _ = sw.open_chat(page, "فرمانده گردان آران و بیدگل", S, CFG)
    assert ok
    ok, err = sw.send_image(page, IMG, "کارنامه عملکرد شهریور ۱۴۰۵ ناحیه آران و بیدگل", S)
    assert ok, f"ارسال ناموفق: {err}"
    assert len(page.sent) == 1
    f, cap = page.sent[0]
    assert Path(f).name == IMG.name, f
    assert cap == "کارنامه عملکرد شهریور ۱۴۰۵ ناحیه آران و بیدگل", cap
    print(f"✅ send_image: پیوست از ورودی مخفی فایل ← کپشن ← ارسال با دکمه ({IMG.name})")


def test_send_image_enter_fallback():
    """وقتی دکمه ارسال پیدا نمی‌شود، Enter باید بفرستد"""
    S2 = dict(S)
    S2["send_button"] = ["#not-exist"]
    page = MockPage(CONTACTS)
    ok, _ = sw.open_chat(page, "مسئول فضای مجازی آران و بیدگل", S, CFG)
    assert ok
    page.no_send_button = True
    ok, err = sw.send_image(page, IMG, "کپشن تست", S2)
    assert ok, f"ارسال با Enter ناموفق: {err}"
    assert page.sent and page.sent[0][1] == "کپشن تست"
    print("✅ send_image: وقتی دکمه‌ی ارسال نیست، Enter پیام را می‌فرستد")


def test_verify_chat_title_mismatch():
    """اگر هدر چت با نام مخاطب نخواند، نباید اجازه‌ی ارسال داده شود"""
    page = MockPage({"مسئول نسرا کاشان": "علی محمدی — نام نمایشیِ متفاوت"})
    ok, err = sw.open_chat(page, "مسئول نسرا کاشان", S, CFG)
    assert not ok and "نیست" in err, (ok, err)
    print("✅ verify_chat_title: ناهمخوانی عنوان گفتگو ← جلوگیری از ارسال اشتباه")



def test_normalize_phone():
    assert sw.normalize_phone("۰۹۱۲ ۳۴۵ ۶۷۸۹") == "09123456789"
    assert sw.normalize_phone("+98 912 345 6789") == "09123456789"
    assert sw.normalize_phone("00989123456789") == "09123456789"
    assert sw.normalize_phone("98-912-345-6789") == "09123456789"
    assert sw.normalize_phone(9123456789) == "09123456789"          # عددی (اکسل)
    assert sw.normalize_phone(9123456789.0) == "09123456789"        # اعشاریِ اکسل
    assert sw.normalize_phone("۰۹۱۲۳۴۵۶۷۸۹") == "09123456789"
    assert sw.normalize_phone("") is None
    assert sw.normalize_phone(None) is None
    assert sw.normalize_phone("بدون شماره") is None
    print("✅ normalize_phone: همه‌ی شکل‌های شماره درست خوانده می‌شوند")


def test_xlsx_loading():
    from openpyxl import Workbook
    tmp = Path(tempfile.mkdtemp(prefix="karnameh_xlsx_"))
    wb = Workbook(); ws = wb.active
    ws.append(["نام ناحیه", "نام ۱", "شماره ۱", "نام ۲", "شماره ۲", "نام ۳", "شماره ۳"])
    ws.append(["ناحیه تست", "خودم", "۰۹۱۲۱۱۱۲۲۳۳", "خودم", "09121112233", "", ""])
    ws.append(["آران و بیدگل", "علی", 9121112244, "رضا", "+98 912 111 2255", "سعید", "۰۰۹۸۹۱۲ ۱۱۱ ۲۲۶۶"])
    ws.append(["ناحیه خالی", "", "", "", "", "", ""])
    xlsx = tmp / "مخاطبین.xlsx"
    wb.save(xlsx)
    cfg = {"roles": ["مسئول نسرا", "فرمانده گردان", "مسئول فضای مجازی"]}
    data = sw.load_recipients_xlsx(xlsx, cfg)
    # شماره‌ی تکراری در یک ناحیه = یک مخاطب
    assert len(data["ناحیه تست"]) == 1 and data["ناحیه تست"][0]["phone"] == "09121112233"
    assert len(data["آران و بیدگل"]) == 3
    assert data["آران و بیدگل"][0]["phone"] == "09121112244"
    assert data["آران و بیدگل"][1]["phone"] == "09121112255"
    assert data["آران و بیدگل"][2]["phone"] == "09121112266"
    assert data["آران و بیدگل"][0]["name"] == "علی"
    # نامِ تمیزِ جستجو نباید نام شخص را شامل شود
    assert data["ناحیه تست"][0]["search_name"] == "مسئول نسرا ناحیه تست"
    assert data["آران و بیدگل"][0]["search_name"] == "مسئول نسرا آران و بیدگل"
    assert "محسن" not in data["ناحیه تست"][0]["search_name"]
    # ردیفِ بدون شماره = ناحیه‌ی ردشده
    assert data["ناحیه خالی"] == []
    print("✅ load_recipients_xlsx: اکسل درست خوانده می‌شود (تکراری‌ها یکی می‌شوند)")


def test_build_tasks_with_xlsx():
    from openpyxl import Workbook
    tmp = Path(tempfile.mkdtemp(prefix="karnameh_task_"))
    img_dir = tmp / "کارنامه‌ها"; img_dir.mkdir()
    (img_dir / "کارنامه_ناحیه تست.png").write_bytes(b"img")
    (img_dir / "کارنامه_کاشان.png").write_bytes(b"img")
    wb = Workbook(); ws = wb.active
    ws.append(["نام ناحیه", "نام ۱", "شماره ۱", "نام ۲", "شماره ۲", "نام ۳", "شماره ۳"])
    ws.append(["ناحیه تست", "خودم", "09120000000", "", "", "", ""])
    ws.append(["ناحیه بی‌تصویر", "", "09120000001", "", "", "", ""])
    xlsx = tmp / "m.xlsx"; wb.save(xlsx)
    cfg = {"images_dir": str(img_dir), "filename_prefix": "کارنامه_",
           "roles": ["مسئول نسرا", "فرمانده گردان", "مسئول فضای مجازی"],
           "image_extensions": [".jpg", ".jpeg", ".png", ".webp", ".bmp"],
           "overrides_csv": "overrides.csv", "recipients_xlsx": str(xlsx)}
    tasks = sw.build_tasks(cfg)
    assert "ناحیه تست" in tasks
    c = tasks["ناحیه تست"]["contacts"][0]
    assert c["phone"] == "09120000000" and c["key"] == "09120000000"
    # ناحیه‌ای که در اکسل نیست → جستجو با نام
    c2 = tasks["کاشان"]["contacts"][0]
    assert c2["phone"] is None and c2["key"] == "مسئول نسرا کاشان"
    print("✅ build_tasks: اکسل اولویت دارد؛ ناحیه‌های بدون اکسل با نام جستجو می‌شوند")


def test_make_caption_no_double_district():
    cfg = {"send_caption": True,
           "caption_template": "کارنامه عملکرد {month} ناحیه {city}",
           "month": "مهر ۱۴۰۵"}
    assert sw.make_caption(cfg, "ناحیه تست") == "کارنامه عملکرد مهر ۱۴۰۵ ناحیه تست"
    assert sw.make_caption(cfg, "آران و بیدگل") == "کارنامه عملکرد مهر ۱۴۰۵ ناحیه آران و بیدگل"
    print("✅ make_caption: دیگر «ناحیه ناحیه تست» تولید نمی‌کند")


def test_send_image_no_evidence_no_text_only():
    """اگر نشانه‌ای از پیوست تصویر در صفحه نباشد، نباید فقط متن فرستاده شود"""
    page = MockPage(CONTACTS)
    ok, _ = sw.open_chat(page, "مسئول نسرا آران و بیدگل", S, CFG)
    assert ok
    page.attach_evidence = False  # شبیه‌سازی: پیوست واقعاً انجام نمی‌شود
    ok2, err2 = sw.send_image(page, IMG, "کپشن", S)
    assert not ok2, "باید ناموفق می‌شد!"
    assert not page.sent, "نباید فقط متن فرستاده می‌شد!"
    print("✅ send_image: بدون پیوستِ واقعی، متنِ تنها فرستاده نمی‌شود")


def test_send_image_attach_modal():
    """رفتار فعلی روبیکا وب: بعد از پیوست، پنجره‌ی «فایل انتخاب شده» باز می‌شود و
    ارسال فقط با دکمه‌ی «ارسال» داخل همان پنجره کامل می‌شود."""
    page = MockPage(CONTACTS)
    page.attach_modal = True
    ok, _ = sw.open_chat(page, "مسئول نسرا آران و بیدگل", S, CFG)
    assert ok
    ok, err = sw.send_image(page, IMG, "کارنامه عملکرد شهریور ۱۴۰۵ ناحیه آران و بیدگل", S)
    assert ok, f"ارسال از پنجره ناموفق: {err}"
    assert not page.modal_open, "پنجره باید بعد از ارسال بسته شده باشد"
    assert len(page.sent) == 1
    f, cap = page.sent[0]
    assert Path(f).name == IMG.name, f
    assert cap == "کارنامه عملکرد شهریور ۱۴۰۵ ناحیه آران و بیدگل", cap
    assert page.composer_value == "", "ورودی اصلی صفحه نباید استفاده شود"
    print("✅ send_image: پنجره‌ی «فایل انتخاب شده» ← متن در ورودی پنجره ← دکمه‌ی ارسال پنجره")


def test_send_image_modal_button_stuck_no_text_only():
    """اگر پنجره بعد از کلیک بسته نشد، نباید متنِ تنها از ورودی اصلی فرستاده شود"""
    page = MockPage(CONTACTS)
    page.attach_modal = True

    def stuck():
        pass  # دکمه کلیک می‌شود اما پنجره بسته نمی‌شود و چیزی ارسال نمی‌شود

    page._modal_send = stuck
    ok, _ = sw.open_chat(page, "فرمانده گردان آران و بیدگل", S, CFG)
    assert ok
    ok2, err2 = sw.send_image(page, IMG, "کپشن", S)
    assert not ok2, "باید ناموفق می‌شد!"
    assert "بسته نشد" in err2
    assert not page.sent, "نباید چیزی (مخصوصاً متن تنها) فرستاده می‌شد"
    print("✅ send_image: پنجره‌ی بسته‌نشده ← توقف بدون ارسال متنِ تنها")


def test_open_chat_by_phone_found():
    page = MockPagePhone({"09121112233": "علی محمدی"})
    ok, err = sw.open_chat_by_phone(page, "09121112233", S)
    assert ok, err
    assert page.chat_with == "09121112233"
    ok2, err2 = sw.send_image(page, IMG, "کپشن تست شماره‌ای", S)
    assert ok2, err2
    assert page.sent and page.sent[0][1] == "کپشن تست شماره‌ای"
    print("✅ open_chat_by_phone: جستجوی شماره ← باز شدن چت ← ارسال تصویر")


def test_open_chat_by_phone_not_found():
    page = MockPagePhone({"09121112233": "علی محمدی"})
    ok, err = sw.open_chat_by_phone(page, "09998887777", S)
    assert not ok and "پیدا نشد" in err, (ok, err)
    assert not page.sent
    print("✅ open_chat_by_phone: شماره‌ی ناموجود ← خطا، بدون ارسال اشتباه")



def test_ensure_test_image_and_placeholder():
    tmp = Path(tempfile.mkdtemp(prefix="karnameh_selfheal_"))
    cfg = {"images_dir": str(tmp / "کارنامه‌ها"), "filename_prefix": "کارنامه_"}
    folder = sw.ensure_test_image(cfg)
    assert folder.is_dir()
    img = folder / "کارنامه_ناحیه تست.png"
    assert img.exists()
    data = img.read_bytes()
    assert data[:8] == b"\x89PNG\r\n\x1a\n" and data[12:16] == b"IHDR", "PNG نامعتبر!"
    assert len(data) > 500
    # دوباره صدا بزنیم → نباید خراب کند یا دوباره بسازد
    before = img.stat().st_mtime_ns
    sw.ensure_test_image(cfg)
    assert img.stat().st_mtime_ns == before
    print("✅ ensure_test_image: پوشه و تصویر تست در صورت نبود ساخته می‌شوند (PNG سالم)")


def test_recipients_xlsx_autocreate():
    tmp = Path(tempfile.mkdtemp(prefix="karnameh_xlsxauto_"))
    path = tmp / "مخاطبین.xlsx"
    cfg = {"roles": ["مسئول نسرا", "فرمانده گردان", "مسئول فضای مجازی"]}
    data = sw.load_recipients_xlsx(path, cfg)
    assert data == {} and path.exists()
    # فایل ساخته‌شده باید با فایل قالب اصلی خوانا باشد
    data2 = sw.load_recipients_xlsx(path, cfg)
    assert data2 == {"ناحیه تست": []}
    print("✅ load_recipients_xlsx: اگر فایل نباشد، قالب خالی خودکار ساخته می‌شود")


ROLES5 = ["مسئولین فضای مجازی", "فرمانده گردان خواهر", "فرمانده گردان برادر",
          "مسئول نسرا خواهر", "مسئول نسرا برادر"]


def test_parse_role_choice():
    assert sw.parse_role_choice("0", ROLES5) == ROLES5
    assert sw.parse_role_choice("", ROLES5) == ROLES5
    assert sw.parse_role_choice("همه", ROLES5) == ROLES5
    assert sw.parse_role_choice("4 5", ROLES5) == ROLES5[3:]
    assert sw.parse_role_choice("۲،۴", ROLES5) == [ROLES5[1], ROLES5[3]]
    assert sw.parse_role_choice("1", ROLES5) == ROLES5[:1]
    assert sw.parse_role_choice("9", ROLES5) is None
    assert sw.parse_role_choice("abc", ROLES5) is None
    print("✅ parse_role_choice: ورودی منوی دسته‌ها درست خوانده می‌شود (ارقام فارسی/همه/نامعتبر)")


def test_make_recipients_xlsx_five_roles():
    tmp = Path(tempfile.mkdtemp(prefix="karnameh_xlsx5_"))
    path = tmp / "مخاطبین.xlsx"
    assert sw.make_recipients_xlsx(path, ROLES5)
    from openpyxl import load_workbook
    ws = load_workbook(path).active
    hs = [c.value for c in ws[1]]
    assert len(hs) == 1 + 2 * len(ROLES5)
    assert "نام در روبیکا — فرمانده گردان خواهر (مهم!)" in hs
    cfg = {"roles": ROLES5}
    data = sw.load_recipients_xlsx(path, cfg)
    assert data == {"ناحیه تست": []}
    print("✅ make_recipients_xlsx: قالب ۵ دسته (۱۱ ستون) ساخته و خوانده می‌شود")


def test_build_tasks_role_selection():
    from openpyxl import Workbook
    tmp = Path(tempfile.mkdtemp(prefix="karnameh_sel_"))
    img_dir = tmp / "کارنامه‌ها"; img_dir.mkdir()
    (img_dir / "کارنامه_کاشان.png").write_bytes(b"img")
    wb = Workbook(); ws = wb.active
    ws.append(["نام ناحیه"] + [x for r in ROLES5 for x in (f"نام {r}", f"شماره {r}")])
    row = ["کاشان"] + [""] * 10
    row[2 + 1 * 2] = "09120000001"  # فرمانده گردان خواهر
    row[2 + 3 * 2] = "09120000003"  # مسئول نسرا خواهر
    ws.append(row)
    xlsx = tmp / "m.xlsx"; wb.save(xlsx)
    cfg = {"images_dir": str(img_dir), "filename_prefix": "کارنامه_",
           "roles": ROLES5,
           "image_extensions": [".png"],
           "overrides_csv": "overrides.csv", "recipients_xlsx": str(xlsx)}
    tasks = sw.build_tasks(cfg)
    assert len(tasks["کاشان"]["contacts"]) == 2
    tasks_sel = sw.build_tasks(cfg, sel_roles=[ROLES5[3]])
    cs = tasks_sel["کاشان"]["contacts"]
    assert len(cs) == 1 and cs[0]["phone"] == "09120000003" and cs[0]["role"] == ROLES5[3]
    # ناحیه‌ای که دسته‌ی انتخابی‌اش خالی است، رد می‌شود
    tasks_sel2 = sw.build_tasks(cfg, sel_roles=[ROLES5[4]])
    assert "کاشان" not in tasks_sel2
    print("✅ build_tasks: فقط دسته‌های انتخابی ارسال می‌شوند؛ ناحیه‌ی بدون آن دسته رد می‌شود")


if __name__ == "__main__":
    test_normalize_phone()
    test_make_caption_no_double_district()
    test_xlsx_loading()
    test_build_tasks_with_xlsx()
    test_open_chat_success()
    test_open_chat_not_found()
    test_send_image()
    test_send_image_enter_fallback()
    test_verify_chat_title_mismatch()
    test_open_chat_by_phone_found()
    test_open_chat_by_phone_not_found()
    test_ensure_test_image_and_placeholder()
    test_recipients_xlsx_autocreate()
    test_send_image_no_evidence_no_text_only()
    test_send_image_attach_modal()
    test_send_image_modal_button_stuck_no_text_only()
    test_parse_role_choice()
    test_make_recipients_xlsx_five_roles()
    test_build_tasks_role_selection()
    print("\n🎉 همه سناریوهای شبیه‌سازی‌شده پاس شدند!")
    print()
    print("=" * 60)
    print("*** ALL TESTS PASSED - SUCCESS ***")
    print("=" * 60)
