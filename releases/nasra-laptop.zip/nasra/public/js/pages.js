import { api, state, navigate, renderRoute, toast, showError, errorText, uploadMedia, openModal, closeModal, copy, downloadBlob, apiBlob, parse, pretty, escapeHtml, faDigits, formatJalali, utcToJalali, relativeTime, badge, stateBadge, statusBadge, stateName, jobStatusName, platformName, notice, empty, formData, checked, confirmExternal, countdownText, refreshApprovalCount } from './app.js?v=20261122-autopilot';
import { monthNames, monthGrid, shiftMonth, jalaliString, todayJalali, gregorianToJalali } from './jalali.js';
import { captionCheck, carouselCheck, imageCheck, reelCheck, storyCheck, mediaKind, mediaUrl, extensionOf, validHttps } from './validators.js';
import { sanitizeSvg, svgToJpeg, downloadText } from './svg-export.js';

const page = (html, mount = null) => ({ html, mount });
const intro = (title, description, actions = '') => `<div class="page-intro"><div><h3>${escapeHtml(title)}</h3><p>${escapeHtml(description)}</p></div><div class="page-actions">${actions}</div></div>`;
const card = (title, body, actions = '', className = '') => `<section class="card ${className}"><div class="card-title"><h3>${escapeHtml(title)}</h3><div class="row">${actions}</div></div>${body}</section>`;
const jsonCard = (title, value) => card(title, `<pre class="json-box">${pretty(value)}</pre>`);
const contentButton = (id, title) => `<button class="link-button btn subtle small-btn" data-content-link="${escapeHtml(id)}">${escapeHtml(title || 'مشاهده محتوا')}</button>`;
const number = n => faDigits(Number(n || 0).toLocaleString('en-US'));
const metricDateLabel = value => { try { const [gy, gm, gd] = String(value).split('-').map(Number); return faDigits(jalaliString(gregorianToJalali(gy, gm, gd))); } catch { return faDigits(value || '—'); } };
const format = f => ({ reel: 'ریلز', carousel: 'کروسل', post: 'پست تصویری', story: 'استوری' }[f] || f || '—');
const gateName = n => ({ 1: 'گیت ۱: انتخاب ایده', 2: 'گیت ۲: تأیید سناریو و راستی‌آزمایی', 3: 'گیت ۳: تأیید بسته نهایی' }[n] || `گیت ${n}`);
const svgRegistry = new Map();
const gateBinders = [];

function registerSvg(svg) { const key = `svg_${Math.random().toString(36).slice(2)}`; svgRegistry.set(key, svg); return key; }
function mediaList(content) { const links = parse(content.media_links_json, []) || []; return links.length ? `<div class="list">${links.map((m, i) => `<div class="list-item row"><span class="badge ${mediaKind(m) === 'video' ? 'purple' : 'info'}">${mediaKind(m) === 'video' ? 'ویدیو' : 'تصویر'} ${faDigits(i + 1)}</span><a href="${escapeHtml(mediaUrl(m))}" target="_blank" rel="noopener" class="truncate">${escapeHtml(mediaUrl(m))}</a></div>`).join('')}</div>` : notice('هنوز لینک رسانه نهایی ثبت نشده است. فایل‌ها به‌صورت پیش‌فرض لینک خارجی هستند.', 'warn'); }
function gateForm(content, gate) {
  if (!gate || gate.status !== 'PENDING') return '';
  const ideas = parse(content.ideation_json, {})?.ideas || [];
  const validation = parse(content.validator_report_json, null);
  return `<form class="card gate-form" data-gate-form data-content-id="${escapeHtml(content.id)}" data-gate-number="${gate.gate_number}">
    <div class="spread"><div><h3>${gateName(gate.gate_number)}</h3><p class="muted small">نسخه ${faDigits(gate.version)} · تصمیم فقط یک‌بار ثبت می‌شود؛ ارسال هم‌زمان «already decided» می‌گیرد.</p></div>${badge('در انتظار مالک', 'warn')}</div>
    ${gate.gate_number === 1 ? `<div class="grid two" style="margin:15px 0">${ideas.map((idea, i) => `<label class="list-item check-label" style="align-items:flex-start"><input type="radio" name="selected_idea_index" value="${i}" ${i === 0 ? 'checked' : ''}><span><strong>${format(idea.format)} · ${escapeHtml(idea.hook || '')}</strong><br><span class="muted small">${escapeHtml(idea.angle || '')} — ${escapeHtml(idea.key_message || '')}</span><br><span class="small">CTA: ${escapeHtml(idea.cta || '')} · تلاش: ${escapeHtml(idea.effort || '')}</span></span></label>`).join('')}</div>` : ''}
    ${gate.gate_number === 2 ? factSummary(parse(content.fact_check_json, {})) : ''}
    ${gate.gate_number === 3 && validation ? `<div class="notice ${validation.ok ? 'ok' : 'danger'}" style="margin:12px 0">${validation.ok ? 'بررسی فنی بدون خطای مسدودکننده است.' : '<strong>خطاهای فنی پیش از تأیید:</strong>'}${(validation.issues || []).map(i => `<div>• ${escapeHtml(i.rule || '')}: ${escapeHtml(i.note || '')}</div>`).join('')}</div>` : ''}
    <label>یادداشت برای درخواست اصلاح (برای تأیید اختیاری)<textarea name="note" placeholder="مثلاً: قلاب کوتاه‌تر شود و منبع ادعای دوم اضافه شود"></textarea></label>
    <div class="form-actions"><button type="button" class="btn danger" data-gate-decision="REJECT">رد محتوا</button><button type="button" class="btn warn" data-gate-decision="REQUEST_CHANGES">درخواست اصلاح و نسخه جدید</button><button type="button" class="btn primary" data-gate-decision="APPROVE">تأیید و ادامه</button></div>
  </form>`;
}
function factSummary(fact) {
  const claims = fact?.claims || [];
  return `<div class="notice ${fact?.overall === 'pass' ? 'ok' : fact?.overall === 'block' ? 'danger' : 'warn'}" style="margin:12px 0"><strong>نتیجه راستی‌آزمایی: ${escapeHtml(fact?.overall || 'ثبت نشده')}</strong><p>${escapeHtml(fact?.notes || '')}</p>${claims.length ? `<div class="table-wrap"><table class="table-compact"><thead><tr><th>ادعا</th><th>حکم</th><th>اعتماد</th><th>پیشنهاد اصلاح</th></tr></thead><tbody>${claims.map(c => `<tr><td>${escapeHtml(c.claim)}</td><td>${badge(c.verdict, c.verdict === 'تأییدشده' ? 'ok' : 'warn')}</td><td>${escapeHtml(c.confidence || '')}</td><td>${escapeHtml(c.fix_suggestion || '')}</td></tr>`).join('')}</tbody></table></div>` : '<p class="small">ادعای قابل راستی‌آزمایی ثبت نشده است.</p>'}</div>`;
}
function bindGateForms(root = document) {
  root.querySelectorAll('[data-gate-form]').forEach(form => {
    if (form.dataset.bound) return; form.dataset.bound = '1';
    form.querySelectorAll('[data-gate-decision]').forEach(button => button.addEventListener('click', async () => {
      const decision = button.dataset.gateDecision;
      const note = form.querySelector('[name="note"]')?.value || '';
      if (decision === 'REQUEST_CHANGES' && !note.trim()) { toast('برای درخواست اصلاح، یادداشت بنویسید', 'error'); form.querySelector('[name="note"]')?.focus(); return; }
      if (decision === 'REJECT' && !window.confirm('محتوا رد شود؟ این تصمیم در لاگ ثبت می‌شود.')) return;
      button.disabled = true;
      try {
        const selected = form.querySelector('[name="selected_idea_index"]:checked')?.value;
        const result = await api(`/api/content/${encodeURIComponent(form.dataset.contentId)}/gates/${form.dataset.gateNumber}`, { method: 'POST', body: { decision, note, selected_idea_index: selected === undefined ? undefined : Number(selected) } });
        toast(result.data?.already_decided ? 'already decided — این گیت قبلاً تصمیم گرفته شده است' : 'تصمیم ثبت شد؛ مراحل بعدی در پس‌زمینه اجرا می‌شوند', 'success');
        closeModal(); await renderRoute(); refreshApprovalCount();
      } catch (error) { showError(error); button.disabled = false; }
    }));
  });
}
function newContentModal() {
  openModal('محتوای جدید', `<form id="new-content-form" class="stack"><label>عنوان<input name="title" required placeholder="مثلاً: سه نشانه پیامک فیشینگ"></label><label>ستون محتوایی<select name="pillar"><option>شایعه‌شکنی و راستی‌آزمایی</option><option>سواد خبری: تشخیص منبع، تیتر، تصویر و ویدیوی دستکاری‌شده</option><option>هوش مصنوعی و جعل: تشخیص محتوای ساختگی و استفاده مسئولانه</option><option>امنیت و حریم خصوصی: کلاهبرداری، فیشینگ، ردپای دیجیتال</option><option>تکنیک‌های شبکه‌های اجتماعی و تولید محتوا (اینستاگرام، روبیکا و ...)</option><option>خانواده، نوجوان و استفاده سالم از رسانه</option><option>اخبار و گزارش کلاس‌ها و کارگاه‌ها</option></select></label><label>پلتفرم‌های هدف<select name="platforms" multiple size="3"><option value="instagram" selected>اینستاگرام</option><option value="telegram" selected>تلگرام</option><option value="rubika" selected>روبیکا</option></select><span class="help">با Ctrl/Command چند گزینه را انتخاب کنید؛ پیش‌فرض هر سه پلتفرم است.</span></label><div class="form-actions"><button type="button" class="btn ghost" data-close-modal>انصراف</button><button class="btn primary" type="submit">ساخت و شروع ایده‌پردازی</button></div></form>`);
  $('#new-content-form')?.addEventListener('submit', async event => { event.preventDefault(); const form = event.target; const data = formData(form); const platforms = [...form.platforms.selectedOptions].map(o => o.value); try { const r = await api('/api/content', { method: 'POST', body: { title: data.title, pillar: data.pillar, target_platforms: platforms.length ? platforms : ['instagram', 'telegram', 'rubika'] } }); closeModal(); toast('محتوا ساخته شد و ideation در صف قرار گرفت', 'success'); navigate(`content/${encodeURIComponent(r.data.id)}`); } catch (error) { showError(error); } });
}
function $(selector, root = document) { return root.querySelector(selector); }
function $$(selector, root = document) { return [...root.querySelectorAll(selector)]; }

async function dashboardPage() {
  const r = await api('/api/dashboard'); const d = r.data;
  const globalUsage = (d.ai_usage || []).find(x => x.scope === 'global') || { total_tokens: 0, requests_count: 0 };
  const settings = await api('/api/settings').catch(() => ({ data: {} }));
  const cap = Number(settings.data?.global_daily_token_cap || 150000);
  const percent = Math.min(100, Math.round((globalUsage.total_tokens || 0) / cap * 100));
  const publishCount = (d.publish_counts || []).reduce((n, x) => n + Number(x.n), 0);
  const html = `${intro('صبح‌بخیر، مالک نسرا', 'مرکز فرمان تیم مجازی؛ هیچ انتشار، پاسخ یا ارسال خارجی بدون تأیید صریح شما انجام نمی‌شود.', '<button class="btn primary" id="dash-new">＋ محتوای جدید</button><button class="btn ghost" id="dash-trend">اجرای سوژه‌یابی</button>')}
    <div class="grid four"><div class="card metric-card"><span class="metric-icon">✓</span><div class="metric-label">گیت‌های در انتظار تصمیم</div><div class="metric-value">${number(d.pending_gates?.length)}</div><div class="metric-note">تأیید، اصلاح یا رد توسط مالک</div></div><div class="card metric-card"><span class="metric-icon">▤</span><div class="metric-label">وظایف نزدیک امروز</div><div class="metric-value">${number(d.today_tasks?.length)}</div><div class="metric-note">زمان‌بندی به وقت تهران</div></div><div class="card metric-card"><span class="metric-icon">◌</span><div class="metric-label">پیام در انتظار بررسی</div><div class="metric-value">${number(d.inbox_pending)}</div><div class="metric-note">پیش‌نویس ادمین، ارسال با شما</div></div><div class="card metric-card"><span class="metric-icon">↗</span><div class="metric-label">کل مسیرهای انتشار</div><div class="metric-value">${number(publishCount)}</div><div class="metric-note">خودکار یا بسته دستی</div></div></div>
    <div class="grid two" style="margin-top:16px"><div>${card('کارهای امروز و نزدیک', d.today_tasks?.length ? `<div class="list">${d.today_tasks.map(j => `<div class="list-item spread"><div><strong>${escapeHtml(j.title)}</strong><div class="small muted">${platformName(j.platform)} · ${format(j.selected_format)} · ${formatJalali(j.scheduled_at_utc)}</div></div><div class="row">${statusBadge(j.status)}${contentButton(j.content_id, 'باز کردن')}</div></div>`).join('')}</div>` : empty('وظیفه فوری ندارید', 'پس از تأیید گیت ۳ و تقویم‌چینی، انتشارهای نزدیک اینجا دیده می‌شوند.'), '<button class="btn ghost small-btn" data-route-link="calendar">تقویم</button>')}</div>
    <div>${card('سهمیه و سلامت', `<div class="quota-line"><span>مصرف تخمینی توکن امروز</span><strong>${number(globalUsage.total_tokens)} / ${number(cap)}</strong></div><div class="progress"><span style="width:${percent}%"></span></div><p class="small muted">درخواست‌های AI: ${number(globalUsage.requests_count)} · سقف‌ها در D1 و پیش از فراخوانی مدل اعمال می‌شوند.</p><div class="notice ${state.integrations?.instagram?.token_status === 'not_configured' ? 'warn' : 'info'}">${state.integrations?.instagram?.token_status === 'not_configured' ? 'اینستاگرام در حالت دستی است؛ بسته انتشار و ثبت URL در مرکز انتشار در دسترس است.' : 'وضعیت اعتبارنامه‌ها را در صفحه یکپارچه‌سازی‌ها بررسی کنید.'}</div>`, '<button class="btn ghost small-btn" data-route-link="settings">سلامت سیستم</button>')}</div></div>
    <div style="margin-top:16px">${card('صف تأییدهای نزدیک', d.pending_gates?.length ? `<div class="list">${d.pending_gates.slice(0, 6).map(g => `<div class="list-item spread"><div><strong>${gateName(g.gate_number)}</strong><div>${escapeHtml(g.title)} <span class="muted small">· نسخه ${faDigits(g.current_version)}</span></div></div><div class="row">${contentButton(g.content_id, 'بررسی و تصمیم')}</div></div>`).join('')}</div>` : empty('صف تأیید خالی است', 'ایده جدید بسازید یا سوژه‌یابی را اجرا کنید.'), '<button class="btn primary small-btn" data-route-link="approvals">مشاهده همه</button>')}</div>
    <div style="margin-top:16px">${card('آخرین محتواها', d.recent_content?.length ? `<div class="table-wrap"><table><thead><tr><th>عنوان</th><th>وضعیت</th><th>فرمت</th><th>نسخه</th><th>آخرین تغییر</th></tr></thead><tbody>${d.recent_content.map(c => `<tr><td>${contentButton(c.id, c.title)}</td><td>${stateBadge(c.state)}</td><td>${format(c.selected_format)}</td><td>${faDigits(c.current_version)}</td><td>${relativeTime(c.updated_at)}</td></tr>`).join('')}</tbody></table></div>` : empty('هنوز محتوایی ساخته نشده است'), '<button class="btn ghost small-btn" data-route-link="pipeline">کانبان تولید</button>')}</div>`;
  return page(html, () => { $('#dash-new')?.addEventListener('click', newContentModal); $('#dash-trend')?.addEventListener('click', async event => { event.target.disabled = true; try { await api('/api/topics/run', { method: 'POST', body: {} }); toast('سوژه‌یابی در پس‌زمینه شروع شد', 'success'); } catch (e) { showError(e); } finally { event.target.disabled = false; } }); $$('[data-route-link]').forEach(b => b.addEventListener('click', () => navigate(b.dataset.routeLink))); });
}

async function approvalsPage() {
  const r = await api('/api/dashboard'); const pending = r.data.pending_gates || [];
  const details = await Promise.all(pending.map(g => api(`/api/content/${encodeURIComponent(g.content_id)}`).then(x => ({ gate: g, detail: x.data })).catch(() => null)));
  const html = `${intro('تصمیم‌های مالک', 'هر سه گیت Approve / Request changes / Reject دارند. درخواست اصلاح با یادداشت، نسخه تازه و اجرای دوباره Agent می‌سازد.', '<button class="btn ghost" id="approval-refresh">↻ تازه‌سازی</button>')}${details.length ? `<div class="stack">${details.filter(Boolean).map(({ gate, detail }) => gateForm(detail.content, detail.gates.find(x => x.id === gate.id) || gate)).join('')}</div>` : empty('گیت بازی برای تصمیم وجود ندارد', 'از کانبان تولید یک محتوای جدید بسازید یا وضعیت کارهای پس‌زمینه را بررسی کنید.')}`;
  return page(html, () => { bindGateForms(); $('#approval-refresh')?.addEventListener('click', renderRoute); });
}

async function pipelinePage() {
  const r = await api('/api/content'); const items = r.data || [];
  const topicResponse = await api('/api/topics').catch(() => ({ data: [] })); const topics = (topicResponse.data || []).filter(t => !t.content_id).slice(0, 12);
  const groups = [['ایده و سناریو', ['IDEATION_PENDING', 'GATE1_PENDING', 'SCRIPTING', 'FACT_CHECKING', 'FACTCHECK_FAIL', 'GATE2_PENDING']], ['تولید و رسانه', ['PRODUCTION', 'MEDIA_PENDING']], ['تحریریه و تأیید نهایی', ['EDITORIAL', 'TECH_CHECKING', 'GATE3_PENDING']], ['تقویم و انتشار', ['SCHEDULING', 'SCHEDULED', 'PUBLISHING']], ['پایان‌یافته', ['PUBLISHED', 'REJECTED', 'ERROR', 'QUOTA_EXHAUSTED']]];
  const html = `${intro('کانبان خط تولید', 'وضعیت‌ها توسط state machine قطعی تغییر می‌کنند، نه توسط مدل. برای دیدن نسخه‌ها و Diff روی هر کارت بزنید.', '<button class="btn primary" id="pipeline-new">＋ محتوای جدید</button><button class="btn ghost" id="pipeline-trend">سوژه‌یابی</button>')}${topics.length ? card('سوژه‌های پیشنهادی trend_scout', `<div class="list">${topics.map(t => `<div class="list-item spread"><div><strong>${escapeHtml(t.title)}</strong><p class="small muted">${escapeHtml(t.why_now || '')} · ${escapeHtml(t.pillar || '')} · حساسیت: ${escapeHtml(t.sensitivity || 'کم')}</p></div><button class="btn subtle small-btn" data-topic-ideate="${escapeHtml(t.id)}">ساخت ایده و شروع گیت ۱</button></div>`).join('')}</div>`, '', '') : ''}<div class="kanban">${groups.map(([label, states]) => { const rows = items.filter(c => states.includes(c.state)); return `<div class="kanban-col"><h4>${label}<span class="badge">${faDigits(rows.length)}</span></h4>${rows.length ? rows.map(c => `<article class="kanban-card"><h5>${escapeHtml(c.title)}</h5><p>${format(c.selected_format)} · نسخه ${faDigits(c.current_version)}</p><div class="spread" style="margin-top:8px">${stateBadge(c.state)}${contentButton(c.id, 'جزئیات')}</div><p style="margin-top:7px">${relativeTime(c.updated_at)}</p></article>`).join('') : '<div class="small muted">موردی نیست</div>'}</div>`; }).join('')}</div>`;
  return page(html, () => {
    $('#pipeline-new')?.addEventListener('click', newContentModal);
    $('#pipeline-trend')?.addEventListener('click', async () => { try { await api('/api/topics/run', { method: 'POST', body: {} }); toast('سوژه‌یابی در صف قرار گرفت', 'success'); } catch (e) { showError(e); } });
    $$('[data-topic-ideate]').forEach(b => b.addEventListener('click', async () => { b.disabled = true; try { const result = await api(`/api/topics/${encodeURIComponent(b.dataset.topicIdeate)}/ideate`, { method: 'POST', body: {} }); toast('محتوا ساخته شد و ایده‌پردازی شروع شد', 'success'); navigate(`content/${encodeURIComponent(result.data.content_id)}`); } catch (e) { showError(e); b.disabled = false; } }));
  });
}

function stageTimeline(content) {
  const stages = [['ایده', ['IDEATION_PENDING', 'GATE1_PENDING']], ['سناریو', ['SCRIPTING', 'FACT_CHECKING', 'FACTCHECK_FAIL', 'GATE2_PENDING']], ['تولید', ['PRODUCTION', 'MEDIA_PENDING']], ['بسته نهایی', ['EDITORIAL', 'TECH_CHECKING', 'GATE3_PENDING']], ['انتشار', ['SCHEDULING', 'SCHEDULED', 'PUBLISHING', 'PUBLISHED']]];
  const current = stages.findIndex(([, states]) => states.includes(content.state));
  return `<div class="timeline">${stages.map(([label], i) => `<div class="timeline-step ${i < current || content.state === 'PUBLISHED' ? 'done' : ''} ${i === current ? 'current' : ''}"><i>${i < current || content.state === 'PUBLISHED' ? '✓' : faDigits(i + 1)}</i>${label}</div>`).join('')}</div>`;
}
function diffLines(oldText, newText) {
  const a = String(oldText || '').split('\n'), b = String(newText || '').split('\n');
  const dp = Array.from({ length: a.length + 1 }, () => new Uint16Array(b.length + 1));
  for (let i = a.length - 1; i >= 0; i--) for (let j = b.length - 1; j >= 0; j--) dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
  let i = 0, j = 0, out = '';
  while (i < a.length && j < b.length) { if (a[i] === b[j]) { out += `<div>${escapeHtml(a[i])}</div>`; i++; j++; } else if (dp[i + 1][j] >= dp[i][j + 1]) out += `<span class="diff-del">− ${escapeHtml(a[i++])}</span>`; else out += `<span class="diff-add">+ ${escapeHtml(b[j++])}</span>`; }
  while (i < a.length) out += `<span class="diff-del">− ${escapeHtml(a[i++])}</span>`;
  while (j < b.length) out += `<span class="diff-add">+ ${escapeHtml(b[j++])}</span>`;
  return out || '<div class="muted">بدون تفاوت</div>';
}
function productionView(content) {
  const production = parse(content.production_json, {}) || {};
  const entries = Object.entries(production);
  if (!entries.length) return empty('خروجی تولید هنوز آماده نشده است');
  return entries.map(([agent, value]) => {
    let body = `<pre class="json-box">${pretty(value)}</pre>`;
    const svgs = [];
    if (value?.svg) svgs.push({ title: 'پوستر SVG', svg: value.svg });
    for (const slide of value?.slides || []) if (slide?.svg) svgs.push({ title: `اسلاید ${slide.n || ''}`, svg: slide.svg });
    if (svgs.length) body = svgs.map(s => { const key = registerSvg(s.svg); return `<h4>${escapeHtml(s.title)}</h4><div class="svg-preview" data-svg-preview="${key}"></div><div class="form-actions"><button class="btn subtle small-btn" data-svg-download="${key}">خروجی JPEG ۱۰۸۰×۱۳۵۰</button><button class="btn ghost small-btn" data-svg-source="${key}">دانلود SVG</button></div>`; }).join('') + body;
    return card(`خروجی ${agent}`, body);
  }).join('');
}
function scriptView(content, script) {
  const ideas = parse(content.ideation_json, {})?.ideas || [];
  const idea = ideas[Number(content.selected_idea_index)] || {};
  const kind = script.format || content.selected_format || '';
  const sections = [`<div class="row">${badge(format(kind), 'info')}${script.reading_level ? badge(`سطح خوانایی: ${script.reading_level}`) : ''}${script.duration_estimate_sec ? badge(`${faDigits(script.duration_estimate_sec)} ثانیه`) : ''}</div>`];
  const fallback = [idea.hook, idea.key_message, idea.cta ? `اقدام پیشنهادی مخاطب: ${idea.cta}` : ''].filter(Boolean).join('\n\n');
  if (String(script.post_body || '').trim()) {
    sections.push(`<div><h4>متن سناریوی ${format(kind)}</h4><div class="inbox-text">${escapeHtml(script.post_body)}</div></div>`);
  } else if (['post', 'story'].includes(kind) && fallback) {
    sections.push(`<div><h4>پیش‌نویس متن بر اساس ایدهٔ تأییدشده</h4><div class="inbox-text">${escapeHtml(fallback)}</div>${idea.angle ? `<p class="small muted"><strong>زاویه روایت:</strong> ${escapeHtml(idea.angle)}</p>` : ''}<p class="small muted">این محتوا با نسخهٔ قبلی سناریونویس ساخته شده است؛ متن خوانا از ایدهٔ تأییدشده نمایش داده می‌شود.</p></div>`);
  }
  if (Array.isArray(script.beats) && script.beats.length) {
    sections.push(`<div class="list">${script.beats.map((beat, i) => `<div class="list-item"><strong>بیت ${faDigits(i + 1)} · ${faDigits(beat.t_start || 0)} تا ${faDigits(beat.t_end || 0)} ثانیه</strong><p>${escapeHtml(beat.voiceover || '')}</p><p class="small"><strong>متن روی تصویر:</strong> ${escapeHtml(beat.on_screen_text || '—')}</p><p class="small muted"><strong>تصویر:</strong> ${escapeHtml(beat.visual || '—')}</p></div>`).join('')}</div>`);
  }
  if (Array.isArray(script.slides) && script.slides.length) {
    sections.push(`<div class="list">${script.slides.map((slide, i) => `<div class="list-item"><strong>اسلاید ${faDigits(slide.n || i + 1)} · ${escapeHtml(slide.headline || '')}</strong><p>${escapeHtml(slide.body || '')}</p><p class="small muted"><strong>راهنمای تصویر:</strong> ${escapeHtml(slide.visual_note || '—')}</p></div>`).join('')}</div>`);
  }
  if (sections.length === 1) sections.push(empty('متن قابل‌نمایشی برای سناریو ثبت نشده است', 'از بخش ایده‌ها یا اجرای دوباره سناریونویس استفاده کنید.'));
  sections.push(`<details><summary class="small muted">نمایش دادهٔ فنی JSON</summary><pre class="json-box">${pretty(script)}</pre></details>`);
  return `<div class="stack">${sections.join('')}</div>`;
}
async function contentPage(id) {
  const r = await api(`/api/content/${encodeURIComponent(id)}`); const d = r.data; const c = d.content;
  const pendingGate = d.gates.find(g => g.status === 'PENDING' && g.version === c.current_version);
  const editorial = parse(c.editorial_json, {}) || {}; const script = parse(c.script_json, {}) || {};
  const versions = d.versions || [];
  const html = `${intro(c.title, `${format(c.selected_format)} · ${stateName(c.state)} · نسخه ${faDigits(c.current_version)}`, '<button class="btn ghost" data-route-link="pipeline">بازگشت به کانبان</button><button class="btn primary" id="content-rerun">اجرای دوباره Agent</button>')}${stageTimeline(c)}${c.state === 'FACTCHECK_FAIL' ? notice('راستی‌آزمایی pass نشده است؛ تولید و تأیید گیت ۲ متوقف شده‌اند. سناریو/منابع را اصلاح کنید و از «اجرای دوباره Agent» گزینه سناریونویس را اجرا کنید.', 'danger') : ''}${pendingGate ? gateForm(c, pendingGate) : ''}
    <div class="grid two" style="margin-top:16px"><div>${card('وضعیت و رسانه', `<div class="row" style="margin-bottom:12px">${stateBadge(c.state)}${badge(`نسخه ${faDigits(c.current_version)}`, 'info')}</div><p class="small muted">آخرین تغییر: ${formatJalali(c.updated_at)}</p>${mediaList(c)}${['CALENDAR', 'SCHEDULED'].includes(c.state) ? `<form id="schedule-form" class="stack" style="margin-top:15px"><label>زمان تأییدشده مالک (جلالی، تهران)<input name="scheduled_jalali" required dir="ltr" value="${escapeHtml(faDigits(c.scheduled_jalali || formatJalali(c.scheduled_at_utc)))}" placeholder="۱۴۰۵/۰۸/۱۳ ۲۱:۰۰"><span class="help">این زمان صریح مالک بر پیشنهاد مدل و fallback تقویم اولویت دارد. بدون Insights، مدل به‌تنهایی زمان تعیین نمی‌کند.</span></label><button class="btn primary small-btn" type="submit">ذخیره زمان مالک</button></form>` : ''}${['MEDIA_PENDING', 'PRODUCTION'].includes(c.state) ? `<div class="notice warn" style="margin-top:12px"><strong>این بسته اینجا متوقف است تا رسانه بدهید.</strong><br>ماشین بدون تصویر/ویدیو جلو نمی‌رود — این تنها جایی است که تولید خودکار متوقف می‌شود.</div><div class="card" style="margin-top:12px;padding:14px"><strong>آپلود از لپ‌تاپ خودتان</strong><p class="small muted" style="margin:6px 0">فایل را انتخاب کنید؛ مستقیم در همین برنامه ذخیره می‌شود و هنگام انتشار برای تلگرام فرستاده می‌شود. نیازی به Drive یا لینک عمومی نیست.</p><form id="media-upload-form" class="stack"><label>فایل (jpg، png، webp، mp4، mov — حداکثر ۲۰ مگابایت)<input type="file" name="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/quicktime" required></label><div id="media-upload-progress" class="small muted"></div><div class="form-actions"><button class="btn primary" type="submit">آپلود و ادامه</button></div></form></div><details style="margin-top:12px"><summary class="small muted">یا لینک عمومی HTTPS بدهید (Drive، هاست خودتان)</summary><form id="media-form" class="stack" style="margin-top:15px"><label>لینک فایل‌های نهایی (هر خط یک HTTPS)<textarea name="urls" required placeholder="https://drive.google.com/...\nhttps://.../poster.jpg">${(parse(c.media_links_json, []) || []).map(mediaUrl).join('\n')}</textarea><span class="help">برای کروسل ۲ تا ۱۰ لینک JPEG؛ برای ریلز لینک MP4/MOV. فایل روی Drive/Dropbox یا هاست شما می‌ماند.</span></label><label>فراداده اختیاری JSON (برای اعتبارسنجی دقیق)<textarea name="metadata" placeholder='[{"width":1080,"height":1350,"format":"jpg"}]'></textarea></label><button class="btn primary" type="submit">ثبت لینک و ادامه به تحریریه</button></form></details>` : ''}`)}</div><div>${card('کپشن و بسته تحریریه', editorial.caption ? `<div class="inbox-text">${escapeHtml(editorial.caption)}</div><div class="row" style="margin:9px 0">${(editorial.hashtags || []).map(h => badge(h, 'info')).join('')}</div><p class="small"><strong>Alt Text:</strong> ${escapeHtml(editorial.alt_text || '—')}</p><p class="small"><strong>CTA:</strong> ${escapeHtml(editorial.cta || '—')}</p><button class="btn ghost small-btn" id="copy-caption">کپی کپشن</button>` : empty('کپشن هنوز ساخته نشده است'))}</div></div>
    <div style="margin-top:16px">${card('سناریو و راستی‌آزمایی', `<div class="tabs"><button class="tab active" data-content-tab="script">سناریو</button><button class="tab" data-content-tab="fact">راستی‌آزمایی</button><button class="tab" data-content-tab="ideation">ایده‌ها</button><button class="tab" data-content-tab="tech">بررسی فنی</button></div><div id="content-tab-script">${scriptView(c, script)}</div><div id="content-tab-fact" class="hidden">${factSummary(parse(c.fact_check_json, {}))}<pre class="json-box">${pretty(parse(c.fact_check_json, {}))}</pre></div><div id="content-tab-ideation" class="hidden"><pre class="json-box">${pretty(parse(c.ideation_json, {}))}</pre></div><div id="content-tab-tech" class="hidden"><pre class="json-box">${pretty(parse(c.tech_check_json, {}))}</pre><pre class="json-box">${pretty(parse(c.validator_report_json, {}))}</pre></div>`)}</div>
    <div style="margin-top:16px">${productionView(c)}</div>
    <div class="grid two" style="margin-top:16px"><div>${card('نسخه‌ها و Diff', versions.length ? versions.map((v, i) => `<div class="version-card"><div class="spread"><strong>نسخه ${faDigits(v.version)} · ${escapeHtml(v.stage)}</strong><button class="btn ghost small-btn" data-version-diff="${i}">مقایسه</button></div><div class="small muted">${formatJalali(v.created_at)} ${v.feedback_note ? `· ${escapeHtml(v.feedback_note)}` : ''}</div></div>`).join('') : empty('نسخه‌ای ثبت نشده است'))}</div><div>${card('مسیرهای انتشار', d.publish_jobs?.length ? `<div class="list">${d.publish_jobs.map(j => `<div class="list-item spread"><div><strong>${platformName(j.platform)}</strong><div class="small muted">${formatJalali(j.scheduled_at_utc)}</div></div>${statusBadge(j.status)}</div>`).join('')}</div>` : empty('پس از تأیید گیت ۳، مسیر انتشار ساخته می‌شود'), '<button class="btn ghost small-btn" data-route-link="publish">مرکز انتشار</button>')}</div></div>
    <div style="margin-top:16px">${card('اجراهای Agent و مصرف', d.agent_runs?.length ? `<div class="table-wrap"><table><thead><tr><th>Agent</th><th>وضعیت</th><th>Repair</th><th>توکن</th><th>زمان</th></tr></thead><tbody>${d.agent_runs.map(run => `<tr><td>${escapeHtml(run.agent_id)}</td><td>${statusBadge(run.status)}</td><td>${run.repair_attempted ? '۱ بار' : '—'}</td><td>${number(run.total_tokens)}</td><td>${formatJalali(run.created_at)}</td></tr>`).join('')}</tbody></table></div>` : empty('اجرایی ثبت نشده است'))}</div>`;
  return page(html, () => {
    bindGateForms();
    $$('[data-route-link]').forEach(b => b.addEventListener('click', () => navigate(b.dataset.routeLink)));
    $('#copy-caption')?.addEventListener('click', () => copy(editorial.caption));
    $('#content-rerun')?.addEventListener('click', () => rerunModal(c));
    $$('[data-content-tab]').forEach(button => button.addEventListener('click', () => { $$('[data-content-tab]').forEach(b => b.classList.toggle('active', b === button)); ['script', 'fact', 'ideation', 'tech'].forEach(name => $(`#content-tab-${name}`)?.classList.toggle('hidden', name !== button.dataset.contentTab)); }));
    $$('[data-svg-preview]').forEach(el => { try { el.innerHTML = sanitizeSvg(svgRegistry.get(el.dataset.svgPreview)); } catch (e) { el.textContent = e.message; } });
    $$('[data-svg-download]').forEach(button => button.addEventListener('click', async () => { button.disabled = true; try { await svgToJpeg(svgRegistry.get(button.dataset.svgDownload), `${c.id}-${button.dataset.svgDownload}.jpg`); toast('JPEG ساخته و دانلود شد', 'success'); } catch (e) { showError(e); } finally { button.disabled = false; } }));
    $$('[data-svg-source]').forEach(button => button.addEventListener('click', () => downloadText(sanitizeSvg(svgRegistry.get(button.dataset.svgSource)), `${c.id}.svg`, 'image/svg+xml;charset=utf-8')));
    $$('[data-version-diff]').forEach(button => button.addEventListener('click', () => { const index = Number(button.dataset.versionDiff); const current = versions[index]; const previous = versions[index + 1] || { snapshot_json: '{}' }; openModal(`Diff نسخه ${faDigits(current.version)}`, `<pre class="json-box" style="max-height:65vh">${diffLines(JSON.stringify(parse(previous.snapshot_json, {}), null, 2), JSON.stringify(parse(current.snapshot_json, {}), null, 2))}</pre>`, true); }));
    $('#schedule-form')?.addEventListener('submit', async event => { event.preventDefault(); try { await api(`/api/content/${encodeURIComponent(c.id)}/schedule`, { method: 'POST', body: { scheduled_jalali: event.target.scheduled_jalali.value } }); toast('زمان مالک ذخیره شد', 'success'); await renderRoute(); } catch (e) { showError(e); } });
    $('#media-upload-form')?.addEventListener('submit', async event => {
      event.preventDefault();
      const form = event.target;
      const file = form.file.files?.[0];
      if (!file) { toast('اول یک فایل انتخاب کنید', 'error'); return; }
      const button = form.querySelector('button');
      const progress = $('#media-upload-progress');
      button.disabled = true;
      if (progress) progress.textContent = `در حال آپلود ${Math.round(file.size / 1024)} کیلوبایت…`;
      try {
        const link = await uploadMedia(file, c.title || '');
        const existing = (parse(c.media_links_json, []) || []).filter(x => x && x.url);
        await api(`/api/content/${encodeURIComponent(c.id)}/media`, { method: 'POST', body: { media_links: [...existing, link] } });
        toast('فایل آپلود شد؛ تحریریه در حال اجرا است', 'success');
        await renderRoute();
      } catch (e) { showError(e); } finally { button.disabled = false; if (progress) progress.textContent = ''; }
    });
    $('#media-form')?.addEventListener('submit', async event => { event.preventDefault(); const form = event.target; const urls = form.urls.value.split(/\n+/).map(x => x.trim()).filter(Boolean); let metadata = []; try { metadata = form.metadata.value.trim() ? JSON.parse(form.metadata.value) : []; } catch { toast('فراداده JSON معتبر نیست', 'error'); return; } const links = urls.map((url, i) => ({ url, ...(metadata[i] || {}), kind: metadata[i]?.kind || (/\.(mp4|mov)(?:[?#]|$)/i.test(url) ? 'video' : 'image'), format: metadata[i]?.format || extensionOf(url) })); try { await api(`/api/content/${encodeURIComponent(c.id)}/media`, { method: 'POST', body: { media_links: links } }); toast('لینک‌ها ثبت شد؛ تحریریه در حال اجرا است', 'success'); await renderRoute(); } catch (e) { showError(e); } });
  });
}
function rerunModal(content) {
  openModal('اجرای دوباره Agent', `<form id="rerun-form" class="stack"><p class="muted small">یک Snapshot پیش از اجرا ذخیره می‌شود. برای اصلاح رسمی گیت، از دکمه «درخواست اصلاح» استفاده کنید تا نسخه جدید ساخته شود.</p><label>Agent<select name="agent_id"><option value="ideation">ایده‌پرداز</option><option value="scriptwriter">سناریونویس</option><option value="fact_checker">راستی‌آزما</option><option value="video_editor">تدوینگر</option><option value="poster_designer">طراح پوستر</option><option value="infographic_designer">طراح اینفوگرافیک</option><option value="sound_engineer">مهندس صدا</option><option value="music_composer">موسیقی</option><option value="editorial">تحریریه</option><option value="tech_advisor">راهبر فنی</option><option value="community_admin">ادمین</option></select></label><label>یادداشت ورودی<textarea name="note" placeholder="بازخورد مالک برای این اجرا"></textarea></label><div class="form-actions"><button type="button" class="btn ghost" data-close-modal>انصراف</button><button class="btn primary" type="submit">اجرای در پس‌زمینه</button></div></form>`);
  $('#rerun-form')?.addEventListener('submit', async event => { event.preventDefault(); const data = formData(event.target); try { await api(`/api/content/${encodeURIComponent(content.id)}/run`, { method: 'POST', body: data }); closeModal(); toast('اجرای دوباره در صف قرار گرفت', 'success'); } catch (e) { showError(e); } });
}

async function calendarPage() {
  const r = await api('/api/calendar'); const jobs = r.data || []; const today = todayJalali(); let cursor = { jy: today.jy, jm: today.jm };
  const draw = () => {
    const cells = monthGrid(cursor.jy, cursor.jm); const events = jobs.filter(j => String(j.scheduled_jalali || '').startsWith(`${cursor.jy}/`));
    const html = `${intro('تقویم محتوایی جلالی', 'زمان‌ها در دیتابیس UTC و در این صفحه به Asia/Tehran نمایش داده می‌شوند؛ اعداد ذخیره‌سازی ASCII هستند.', '<button class="btn primary" data-route-link="pipeline">＋ محتوای جدید</button>')}${card('تقویم انتشار', `<div class="calendar-head"><div class="row"><button class="icon-btn" id="cal-prev" aria-label="ماه قبل">‹</button><h3 style="margin:0">${monthNames[cursor.jm - 1]} ${faDigits(cursor.jy)}</h3><button class="icon-btn" id="cal-next" aria-label="ماه بعد">›</button></div><button class="btn ghost small-btn" id="cal-today">امروز · ${faDigits(today.date)}</button></div><div class="calendar-grid">${['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'].map(x => `<div class="calendar-weekday">${x}</div>`).join('')}${cells.map(cell => { const key = jalaliString(cell); const dayJobs = jobs.filter(j => String(j.scheduled_jalali || '').startsWith(key)); const isToday = key === today.date; return `<div class="calendar-day ${cell.other ? 'other' : ''} ${isToday ? 'today' : ''}"><span class="day-number">${faDigits(cell.jd)}</span>${dayJobs.slice(0, 3).map(j => `<button class="calendar-event ${j.status === 'PUBLISHED' ? 'published' : j.manual_mode ? 'manual' : ''}" data-content-link="${escapeHtml(j.content_id)}" title="${escapeHtml(j.title)}">${escapeHtml(platformName(j.platform))} · ${escapeHtml(j.title)}</button>`).join('')}${dayJobs.length > 3 ? `<span class="small muted">+${faDigits(dayJobs.length - 3)}</span>` : ''}</div>`; }).join('')}</div><p class="small muted" style="margin-bottom:0">رویدادهای رنگی: سبز منتشرشده، زرد بسته دستی. برای جزئیات روی رویداد بزنید.</p>`)}`;
    $('#app').innerHTML = html;
    $('#cal-prev')?.addEventListener('click', () => { cursor = shiftMonth(cursor.jy, cursor.jm, -1); draw(); });
    $('#cal-next')?.addEventListener('click', () => { cursor = shiftMonth(cursor.jy, cursor.jm, 1); draw(); });
    $('#cal-today')?.addEventListener('click', () => { cursor = { jy: today.jy, jm: today.jm }; draw(); });
    $$('[data-route-link]').forEach(b => b.addEventListener('click', () => navigate(b.dataset.routeLink)));
  };
  return page('<div></div>', draw);
}

function sourceForm(source = {}) {
  return `<form id="source-edit-form" class="stack"><input type="hidden" name="id" value="${escapeHtml(source.id || '')}"><label>نام منبع<input name="title" required value="${escapeHtml(source.title || '')}" placeholder="مثلاً: گزارش کارگاه سوادرسانه"></label><div class="form-grid"><label>نوع<select name="source_type"><option value="manual">یادداشت/ورودی دستی</option><option value="telegram_channel">کانال تلگرامی</option><option value="rss">RSS رسمی</option><option value="trend">ترند (گوگل ترندز / اینستاگرام / تیک‌تاک / پینترست)</option><option value="url">لینک وب‌سایت</option></select></label><label>سطح اعتماد<select name="trust_tier"><option>داخلی</option><option>بررسی‌شده</option><option>رسمی</option><option>نیازمند بررسی</option></select></label></div><label>شناسه یا آدرس (بدون ساختن URL)<input name="identifier" dir="ltr" value="${escapeHtml(source.identifier || '')}" placeholder="@channel یا https://..."></label><label>قاعده اعتبار/ذکر منبع<input name="credit_rule" value="${escapeHtml(source.credit_rule || '')}"></label><label>مجوز بازنشر<input name="reuse_permission" value="${escapeHtml(source.reuse_permission || '')}"></label><label>یادداشت<textarea name="notes">${escapeHtml(source.notes || '')}</textarea></label><label class="check-label"><input type="checkbox" name="enabled" ${source.enabled === 0 ? '' : 'checked'}> فعال و وارد context سوژه‌یاب شود</label><div class="form-actions"><button type="button" class="btn ghost" data-close-modal>انصراف</button><button class="btn primary" type="submit">ذخیره منبع</button></div></form>`;
}
function bindSourceForm(source = null) {
  const editForm = $('#source-edit-form');
  if (source && editForm) { editForm.source_type.value = source.source_type || 'manual'; editForm.trust_tier.value = source.trust_tier || 'داخلی'; }
  editForm?.addEventListener('submit', async event => { event.preventDefault(); const form = event.target; const data = formData(form); data.enabled = form.enabled.checked; try { if (source?.id) await api(`/api/sources/${encodeURIComponent(source.id)}`, { method: 'PUT', body: data }); else await api('/api/sources', { method: 'POST', body: data }); closeModal(); toast('منبع ذخیره شد', 'success'); await renderRoute(); } catch (e) { showError(e); } });
}
async function sourcesPage() {
  const r = await api('/api/sources'); const sources = r.data || []; const items = r.items || [];
  const html = `${intro('منابع و اعتبار محتوا', 'هیچ URL واقعی ساخته نشده است. متن خارجی پیش از ورود به Agent داخل <untrusted> قرار می‌گیرد و فقط «داده» است.', '<button class="btn primary" id="source-new">＋ منبع جدید</button><button class="btn ghost" id="source-fetch-rss">خواندن RSSهای فعال</button>')}${card('ترند روز — منبع ایده‌های شما', `<div class="stack small"><p>اینجا «ترند» را از «خبر» جدا می‌کنیم. ترند یعنی چیزی که در اینستاگرام، تیک‌تاک، پینترست یا اکس <strong>عدد واقعی بازدید</strong> گرفته است.</p><div class="row"><button class="btn primary small-btn" id="source-trend-hunt">شکار ترند امروز</button><button class="btn ghost small-btn" id="source-trend-feed">خواندن گوگل ترندز</button><button class="btn ghost small-btn" id="source-trend-new">＋ منبع ترند</button></div><p class="muted">«شکار ترند» فقط آیتم‌های «ترندی که خودتان دیده‌اید» را می‌خواند و فرصت محتوا می‌سازد. برای گوگل ترندز، منبع قالب «گوگل ترندز ایران» را ویرایش کنید و «فعال» را روشن کنید.</p><p class="muted">⚠️ هیچ عددی ساخته نمی‌شود: اگر بازدید را ننویسید، عامل هوش مصنوعی می‌نویسد «عدد در دسترس نبود» و آن آیتم را «وایرال» نمی‌نامد.</p></div>`)}${notice('سوژه‌یاب بدون منبع هم کار می‌کند و از دانش عمومی پیشنهاد می‌دهد؛ ولی چنین سوژه‌ای «بدون منبع» ثبت می‌شود و اگر گزینهٔ «بدون منبع تأییدشده تأیید نشود» در اتوپایلوت روشن باشد، تا وقتی منبع اضافه نکنید جلوتر نمی‌رود. برای محتوای خبری، اول یک منبع اضافه کنید.', 'info')}<div class="grid two" style="margin-top:16px"><div>${card('کتابخانه منابع', sources.length ? sources.map(s => `<div class="list-item"><div class="spread"><div><strong>${escapeHtml(s.title)}</strong><div class="small muted">${escapeHtml(s.source_type)} · ${escapeHtml(s.trust_tier)} · ${s.enabled ? 'فعال' : 'غیرفعال'}</div></div><button class="btn ghost small-btn" data-source-edit="${escapeHtml(s.id)}">ویرایش</button></div>${s.identifier ? `<p class="small ltr">${escapeHtml(s.identifier)}</p>` : '<p class="small muted">بدون شناسه — قالب خام</p>'}<p class="small">${escapeHtml(s.credit_rule || '')}</p><p class="small muted">${escapeHtml(s.reuse_permission || '')}</p>${s.notes ? `<p class="small">${escapeHtml(s.notes)}</p>` : ''}<form class="row" data-source-item-form="${escapeHtml(s.id)}"><input name="title" placeholder="عنوان آیتم/گزارش" required style="flex:1;min-width:150px"><input name="raw_text" placeholder="متن خام برای سوژه‌یابی" required style="flex:2;min-width:200px">${s.source_type === 'trend' ? '<input name="engagement_views" placeholder="بازدید (عدد واقعی، مثلاً 120000 یا 1.2M)" dir="ltr" style="width:190px"><input name="engagement_likes" placeholder="لایک" dir="ltr" style="width:110px">' : ''}<button class="btn subtle small-btn" type="submit">افزودن آیتم</button></form></div>`).join('') : empty('منبعی ثبت نشده است'))}</div><div>${card('آخرین آیتم‌های منبع', items.length ? `<div class="list">${items.map(i => `<div class="list-item"><strong>${escapeHtml(i.title)}</strong><div class="small muted">${formatJalali(i.created_at)} · ${escapeHtml(i.pillar_hint || 'بدون ستون')}</div></div>`).join('')}</div>` : empty('آیتمی وجود ندارد', 'متن یک گزارش یا خبر را از کادر «افزودن آیتم» زیر هر منبع وارد کنید. برای خواندن خودکار، یک منبع با نوع «RSS رسمی» بسازید و بعد دکمهٔ «خواندن RSSهای فعال» را بزنید.'), '<button class="btn ghost small-btn" id="source-run-trend">اجرای trend_scout</button>')}</div></div>`;
  return page(html, () => {
    $('#source-new')?.addEventListener('click', () => { openModal('منبع جدید', sourceForm()); bindSourceForm(); });
    $('#source-fetch-rss')?.addEventListener('click', async event => {
      event.target.disabled = true;
      try {
        const result = await api('/api/sources/fetch', { method: 'POST', body: {} });
        const list = result.data || [];
        const imported = list.reduce((n, x) => n + Number(x.imported || 0), 0);
        /* "0 items" is not a success when every feed failed: say which one failed
           and why, otherwise the owner keeps pressing the button. */
        const failed = list.filter(x => x.ok === false);
        if (!list.length) toast('هیچ منبع RSS فعالی نیست. اول یک منبع با نوع «RSS رسمی» بسازید.', 'error');
        else if (failed.length) toast(`خواندن RSS ناموفق: ${failed.map(x => x.error || 'خطای نامشخص').join(' · ')}. آیتم تازه: ${number(imported)}`, 'error');
        else toast(`خواندن RSS تمام شد؛ ${number(imported)} آیتم تازه`, 'success');
        await renderRoute();
      } catch (e) { showError(e); } finally { event.target.disabled = false; }
    });
    $$('[data-source-edit]').forEach(b => b.addEventListener('click', () => { const source = sources.find(s => s.id === b.dataset.sourceEdit); openModal('ویرایش منبع', sourceForm(source)); bindSourceForm(source); }));
    $$('[data-source-item-form]').forEach(form => form.addEventListener('submit', async event => {
      event.preventDefault();
      const data = formData(form);
      /* Numbers the owner typed beat anything a model could guess, so they travel
         as structured engagement rather than being buried in the raw text. */
      const engagement = {};
      if (data.engagement_views) engagement.views = data.engagement_views;
      if (data.engagement_likes) engagement.likes = data.engagement_likes;
      delete data.engagement_views; delete data.engagement_likes;
      if (Object.keys(engagement).length) data.engagement = engagement;
      try { await api(`/api/sources/${encodeURIComponent(form.dataset.sourceItemForm)}/items`, { method: 'POST', body: data }); toast('آیتم منبع اضافه شد', 'success'); await renderRoute(); } catch (e) { showError(e); }
    }));

    /* Trend hunting is a different question from news ideation, so it gets its own
       button; both land in «سوژه‌های پیشنهادی» on the kanban page. */
    const runAgent = async (mode, done) => {
      try {
        await api('/api/topics/run', { method: 'POST', body: mode ? { mode } : {} });
        toast(done, 'success');
        setTimeout(() => renderRoute().catch(() => {}), 6000);
      } catch (e) { showError(e); }
    };
    $('#source-trend-hunt')?.addEventListener('click', () => runAgent('trend', 'شکار ترند شروع شد؛ چند ثانیه بعد سوژه‌های پیشنهادی تازه می‌شوند'));
    $('#source-trend-new')?.addEventListener('click', () => { openModal('منبع ترند جدید', sourceForm({ source_type: 'trend', trust_tier: 'نیازمند بررسی' })); bindSourceForm({ source_type: 'trend', trust_tier: 'نیازمند بررسی' }); });
    $('#source-trend-feed')?.addEventListener('click', async event => {
      event.target.disabled = true;
      try {
        const result = await api('/api/sources/fetch', { method: 'POST', body: {} });
        const list = result.data || [];
        const trends = list.filter(x => x.ok && Number(x.imported) > 0);
        const failed = list.filter(x => !x.ok);
        if (!list.length) toast('هیچ منبع RSS/ترند فعالی با آدرس نیست. منبع «گوگل ترندز ایران» را ویرایش کنید و «فعال» را روشن کنید.', 'error');
        else if (failed.length && !trends.length) toast(`خواندن ناموفق: ${failed.map(x => x.error || 'خطای نامشخص').join(' · ')}. اگر گوگل در شبکه شما باز نیست، متن ترند را دستی اضافه کنید.`, 'error');
        else toast(`خواندن تمام شد؛ ${number(trends.reduce((n, x) => n + Number(x.imported || 0), 0))} آیتم ترند تازه`, 'success');
        await renderRoute();
      } catch (e) { showError(e); } finally { event.target.disabled = false; }
    });
    $('#source-run-trend')?.addEventListener('click', async () => {
      try {
        await api('/api/topics/run', { method: 'POST', body: {} });
        /* The agent writes topics a few seconds later; reload once so the owner
           sees the result instead of an unchanged empty page. */
        toast('سوژه‌یابی شروع شد؛ چند ثانیه بعد صفحه تازه می‌شود', 'success');
        setTimeout(() => renderRoute().catch(() => {}), 6000);
      } catch (e) { showError(e); }
    });
  });
}

async function playbookPage() {
  const [p, b] = await Promise.all([api('/api/playbook'), api('/api/brand')]); const playbook = p.data || {}; const brand = b.data || {}; const pillars = parse(playbook.pillars_json, []) || [];
  const color = (key, label) => `<label>${label}<input type="color" name="${key}" value="${escapeHtml(brand[key] || '#0f4c5c')}"></label>`;
  const html = `${intro('پلی‌بوک و Brand Kit', 'هر ویرایش پلی‌بوک نسخه جدید می‌سازد. رنگ‌ها و فونت system stack به طراحان به‌صورت DATA داده می‌شود.', '')}<div class="tabs"><button class="tab active" data-knowledge-tab="playbook">پلی‌بوک نسخه ${faDigits(playbook.version || 1)}</button><button class="tab" data-knowledge-tab="brand">Brand Kit</button><button class="tab" data-knowledge-tab="specs">Platform specs</button></div><div id="knowledge-playbook">${card('ویرایش پلی‌بوک', `<form id="playbook-form" class="stack"><label>عنوان<input name="title" value="${escapeHtml(playbook.title || '')}"></label><label>ستون‌های محتوایی (هر خط یک ستون)<textarea name="pillars" rows="7">${escapeHtml(pillars.join('\n'))}</textarea></label><label>لحن و قواعد زبانی<textarea name="tone_of_voice" rows="5">${escapeHtml(playbook.tone_of_voice || '')}</textarea></label><label>مخاطب<textarea name="audience_desc" rows="3">${escapeHtml(playbook.audience_desc || '')}</textarea></label><label>کلمات/ادعاهای ممنوع (هر خط یک مورد)<textarea name="banned" rows="4">${escapeHtml((parse(playbook.banned_words_json, []) || []).join('\n'))}</textarea></label><label>قواعد زمان‌بندی<textarea name="posting_rules_text" rows="4">${escapeHtml(playbook.posting_rules_text || '')}</textarea></label><label>Markdown کامل<textarea name="raw_markdown" rows="9" dir="ltr">${escapeHtml(playbook.raw_markdown || '')}</textarea></label><label>یادداشت نسخه<input name="note" placeholder="دلیل ویرایش"></label><div class="form-actions"><button class="btn primary" type="submit">ذخیره به‌عنوان نسخه جدید</button></div></form>`)}</div><div id="knowledge-brand" class="hidden">${card('رنگ، فونت و هویت بصری', `<form id="brand-form" class="stack"><div class="form-grid three">${color('primary_color', 'رنگ اصلی')}${color('secondary_color', 'رنگ دوم')}${color('accent_color', 'رنگ تأکید')}${color('bg_light_color', 'پس‌زمینه روشن')}${color('bg_dark_color', 'پس‌زمینه تیره')}${color('text_dark_color', 'متن تیره')}${color('text_light_color', 'متن روشن')}</div><label>Font stack (بدون Google Fonts CDN)<input name="font_family_css" dir="ltr" value="${escapeHtml(brand.font_family_css || '')}"></label><label>لینک لوگو (اختیاری، HTTPS)<input name="logo_url" dir="ltr" value="${escapeHtml(brand.logo_url || '')}"></label><label>متن واترمارک<input name="watermark_text" value="${escapeHtml(brand.watermark_text || '')}"></label><label>حاشیه امن SVG (پیکسل)<input name="safe_margin_px" type="number" min="0" max="300" value="${brand.safe_margin_px || 80}"></label><label>خلاصه لحن<textarea name="tone_summary">${escapeHtml(brand.tone_summary || '')}</textarea></label><div class="form-actions"><button class="btn primary" type="submit">ذخیره Brand Kit</button></div></form>`)}</div><div id="knowledge-specs" class="hidden">${card('مشخصات پلتفرم‌ها و تاریخ راستی‌آزمایی', '<div id="specs-content">در حال بارگذاری…</div>')}</div>`;
  return page(html, async () => {
    $$('[data-knowledge-tab]').forEach(button => button.addEventListener('click', () => { $$('[data-knowledge-tab]').forEach(b => b.classList.toggle('active', b === button)); ['playbook', 'brand', 'specs'].forEach(name => $(`#knowledge-${name}`)?.classList.toggle('hidden', name !== button.dataset.knowledgeTab)); }));
    $('#playbook-form')?.addEventListener('submit', async event => { event.preventDefault(); const data = formData(event.target); try { await api('/api/playbook', { method: 'PUT', body: { title: data.title, pillars: data.pillars.split(/\n+/).map(x => x.trim()).filter(Boolean), tone_of_voice: data.tone_of_voice, audience_desc: data.audience_desc, banned_words: data.banned.split(/\n+/).map(x => x.trim()).filter(Boolean), posting_rules_text: data.posting_rules_text, raw_markdown: data.raw_markdown, note: data.note } }); toast('پلی‌بوک نسخه جدید شد', 'success'); await renderRoute(); } catch (e) { showError(e); } });
    $('#brand-form')?.addEventListener('submit', async event => { event.preventDefault(); const data = formData(event.target); try { await api('/api/brand', { method: 'PUT', body: data }); toast('Brand Kit ذخیره شد', 'success'); } catch (e) { showError(e); } });
    try {
      const specs = await api('/api/platform-specs');
      $('#specs-content').innerHTML = `<div class="notice info">این مقادیر از D1 خوانده و به Agents به‌عنوان DATA داده می‌شوند؛ از حافظه مدل استفاده نمی‌شود. تاریخ آخرین بررسی: ${faDigits('2026-11-04')}</div><div class="stack" style="margin-top:12px">${(specs.data || []).map(s => `<details class="list-item"><summary><strong>${escapeHtml(s.platform)} · ${escapeHtml(s.format)} · ${escapeHtml(s.spec_key)}</strong></summary><p class="small">${escapeHtml(s.summary_fa)}</p><pre class="json-box">${pretty(parse(s.spec_value_json, {}))}</pre><a class="small ltr" href="${escapeHtml(s.source_url)}" target="_blank" rel="noopener">${escapeHtml(s.source_url)}</a><div class="small muted">last_verified: ${faDigits(s.last_verified)}</div></details>`).join('')}</div>`;
    } catch { $('#specs-content').textContent = 'مشخصات پلتفرم در دسترس نیست.'; }
  });
}

async function agentsPage() {
  const r = await api('/api/agents'); const agents = r.data || []; let selected = agents[0]?.id;
  const html = `${intro('تیم مجازی و ویرایش پرامپت', 'پرامپت‌ها از جدول agents در D1 خوانده می‌شوند؛ هیچ پرامپت runtime-only در Worker وجود ندارد. خروجی فقط JSON و بدون ابزار است.', '<button class="btn ghost" id="agents-reload">↻</button>')}${notice('ویرایش پرامپت، version Agent را زیاد می‌کند و cache ورودی‌های جدید را از نسخه قبلی جدا می‌کند. تست اجرا هیچ اقدام خارجی ندارد.', 'info')}<div class="grid two" style="margin-top:16px"><div>${card('۱۲ عضو تیم', `<label>انتخاب Agent<select id="agent-select">${agents.map(a => `<option value="${escapeHtml(a.id)}">${escapeHtml(a.name_fa)} · ${escapeHtml(a.id)}</option>`).join('')}</select></label><div id="agent-list" class="list" style="margin-top:14px">${agents.map(a => `<div class="list-item spread"><div><strong>${escapeHtml(a.name_fa)}</strong><div class="small muted">${escapeHtml(a.role_group)} · نسخه ${faDigits(a.version)}</div></div>${a.enabled ? badge('فعال', 'ok') : badge('غیرفعال', 'warn')}</div>`).join('')}</div>`)}</div><div id="agent-editor"></div></div>`;
  const drawEditor = () => {
    const a = agents.find(x => x.id === selected); if (!a) return;
    $('#agent-editor').innerHTML = card(`ویرایش ${a.name_fa}`, `<form id="agent-form" class="stack"><div class="form-grid"><label>Provider<select name="provider"><option value="default">پیش‌فرض Secrets</option><option value="workers_ai">Workers AI</option><option value="gemini">Gemini</option><option value="openai_compatible">OpenAI-compatible</option></select></label><label>Model<input name="model" dir="ltr" value="${escapeHtml(a.model || '')}" placeholder="پیش‌فرض provider"></label></div><label>Base URL برای OpenAI-compatible (اختیاری)<input name="base_url" dir="ltr" value="${escapeHtml(a.base_url || '')}"></label><div class="form-grid"><label>حداکثر توکن خروجی<input name="max_tokens" type="number" min="256" max="12000" value="${a.max_tokens}"></label><label>سقف توکن روزانه Agent<input name="daily_token_cap" type="number" min="100" value="${a.daily_token_cap}"></label></div><label>System prompt فارسی<textarea name="system_prompt" rows="18" required>${escapeHtml(a.system_prompt)}</textarea></label><label class="check-label"><input type="checkbox" name="enabled" ${a.enabled ? 'checked' : ''}> Agent فعال باشد</label><div class="form-actions"><button type="button" class="btn ghost" id="agent-restore">بازگردانی پرامپت اولیه</button><button type="submit" class="btn primary">ذخیره و افزایش نسخه</button></div></form><hr style="border:0;border-top:1px solid var(--line);margin:18px 0"><form id="agent-test-form" class="stack"><h4>تست اجرای JSON</h4><label>متن آزمایشی (به‌عنوان داده غیرقابل اعتماد)<textarea name="text" placeholder="یک مثال برای تست این Agent"></textarea></label><button class="btn subtle" type="submit">اجرای تست بدون side effect</button><div id="agent-test-result"></div></form>`);
    const form = $('#agent-form'); form.provider.value = a.provider || 'default';
    form.addEventListener('submit', async event => { event.preventDefault(); const data = formData(form); data.enabled = form.enabled.checked; try { const result = await api(`/api/agents/${encodeURIComponent(a.id)}`, { method: 'PUT', body: data }); Object.assign(a, result.data); toast('پرامپت ذخیره شد', 'success'); drawEditor(); } catch (e) { showError(e); } });
    $('#agent-restore')?.addEventListener('click', () => { form.system_prompt.value = a.default_system_prompt; toast('پرامپت اولیه در فرم قرار گرفت؛ برای ذخیره تأیید کنید'); });
    $('#agent-test-form')?.addEventListener('submit', async event => { event.preventDefault(); const button = event.target.querySelector('button'); button.disabled = true; $('#agent-test-result').innerHTML = '<p class="muted">در حال اجرا…</p>'; try { const result = await api(`/api/agents/${encodeURIComponent(a.id)}/test`, { method: 'POST', body: { text: event.target.text.value } }); $('#agent-test-result').innerHTML = `<div class="notice ok">تست موفق · Repair: ${result.data.repair_attempted ? '۱ بار' : '۰'} · توکن: ${number(result.data.usage.total_tokens)}</div><pre class="json-box">${pretty(result.data.parsed)}</pre>`; } catch (e) { $('#agent-test-result').innerHTML = `<div class="notice danger">${escapeHtml(errorText(e))}</div>`; } finally { button.disabled = false; } });
  };
  return page(html, () => { drawEditor(); $('#agent-select')?.addEventListener('change', e => { selected = e.target.value; drawEditor(); }); $('#agents-reload')?.addEventListener('click', renderRoute); });
}

async function inboxPage() {
  const r = await api('/api/inbox'); const messages = r.data || [];
  const html = `${intro('صندوق ورودی و پاسخ‌های پیش‌نویس', 'community_admin فقط دسته‌بندی و پیش‌نویس می‌سازد. ارسال خصوصی/عمومی فقط با دکمه تأیید مالک و پس از بررسی پنجره‌های رسمی انجام می‌شود.', '<button class="btn primary" id="inbox-manual">＋ ورود دستی کامنت/DM</button>')}${notice('قواعد کدشده: یک پاسخ خصوصی برای هر کامنت تا ۷ روز؛ دایرکت فقط در پنجره ۲۴ ساعته از آخرین پیام کاربر و پاسخ بعدی فقط پس از پیام تازه او. پیام انبوه یا سرد وجود ندارد. مسیر Human Agent در GUIDE.fa.md توضیح داده شده است.', 'info')}<div class="stack" style="margin-top:16px">${messages.length ? messages.map(m => { const classification = parse(m.classification_json, {}) || {}; const window = m.window || {}; const deadline = Date.now() + Number(window.remaining_seconds || 0) * 1000; const isDm = m.item_type === 'dm'; const allowed = window.allowed; return `<article class="card" data-inbox-card="${escapeHtml(m.id)}"><div class="spread"><div class="row"><div class="avatar">${escapeHtml((m.sender_username || 'ک').slice(0, 1))}</div><div><strong>${escapeHtml(m.sender_username)}</strong><div class="small muted">${isDm ? 'دایرکت' : 'کامنت'} · ${formatJalali(m.received_at)} · ${m.manual_entry ? 'ورودی دستی' : 'webhook'}</div></div></div><div class="row">${m.escalate ? badge('نیازمند بررسی فوری', 'danger') : ''}${m.is_hidden ? badge('پنهان', 'warn') : ''}${statusBadge(m.reply_status)}</div></div><div class="inbox-text" style="margin:14px 0">${escapeHtml(m.text_raw)}</div><div class="grid two"><div><div class="row">${classification.category ? badge(classification.category, 'info') : ''}${classification.sentiment ? badge(classification.sentiment, 'purple') : ''}</div><p class="small muted">${escapeHtml(classification.reason || 'در انتظار دسته‌بندی ادمین')}</p><div class="notice ${allowed ? 'ok' : 'warn'}"><strong>${isDm ? 'پنجره ۲۴ ساعته' : 'پنجره پاسخ خصوصی ۷ روزه'}:</strong> <span class="countdown ${allowed ? '' : 'expired'}" data-countdown="${deadline}">${countdownText(window.remaining_seconds)}</span><br><span class="small">${escapeHtml(window.reason || (allowed ? 'ارسال مجاز است؛ دوباره در لحظه ارسال بررسی می‌شود.' : 'ارسال خودکار مسدود است.'))}</span></div></div><div><label>پیش‌نویس پاسخ (قابل ویرایش)<textarea data-reply-text>${escapeHtml(m.draft_reply || '')}</textarea></label><div class="form-actions"><button class="btn ghost small-btn" data-inbox-redraft="${escapeHtml(m.id)}">ساخت دوباره پیش‌نویس</button>${!isDm ? `<button class="btn subtle small-btn" data-inbox-send="public" data-inbox-id="${escapeHtml(m.id)}">تأیید پاسخ عمومی</button><button class="btn primary small-btn" data-inbox-send="private" data-inbox-id="${escapeHtml(m.id)}" ${allowed ? '' : 'disabled'}>تأیید پاسخ خصوصی</button><button class="btn warn small-btn" data-inbox-hide="${escapeHtml(m.id)}">${m.is_hidden ? 'آشکارسازی' : 'پنهان‌سازی'}</button>` : `<button class="btn primary small-btn" data-inbox-send="dm" data-inbox-id="${escapeHtml(m.id)}" ${allowed ? '' : 'disabled'}>تأیید و ارسال DM</button>`}</div></div></div>${m.sent_reply_text ? `<p class="small text-ok">پاسخ ثبت‌شده: ${escapeHtml(m.sent_reply_text)}</p>` : ''}</article>`; }).join('') : empty('صندوق ورودی خالی است', 'Webhook اینستاگرام یا ورودی دستی، پیام‌ها را اینجا می‌آورد.')}</div>`;
  return page(html, () => {
    $('#inbox-manual')?.addEventListener('click', () => { openModal('ورود دستی کامنت یا دایرکت', `<form id="manual-inbox-form" class="stack"><div class="form-grid"><label>نوع<select name="item_type"><option value="comment">کامنت</option><option value="dm">دایرکت</option></select></label><label>نام کاربر<input name="sender_username" value="ورودی دستی"></label></div><label>متن<textarea name="text_raw" required></textarea></label><label>زمان دریافت (اختیاری؛ برای تست پنجره‌ها)<input name="received_at" type="datetime-local"></label><p class="help">در Manual Mode همان مدل داده و همان قواعد پنجره اعمال می‌شود؛ ارسال واقعی بدون credential انجام نمی‌شود.</p><div class="form-actions"><button type="button" class="btn ghost" data-close-modal>انصراف</button><button class="btn primary" type="submit">ثبت و ساخت پیش‌نویس</button></div></form>`); $('#manual-inbox-form')?.addEventListener('submit', async event => { event.preventDefault(); const data = formData(event.target); if (data.received_at) data.received_at = new Date(data.received_at).toISOString(); try { await api('/api/inbox/manual', { method: 'POST', body: data }); closeModal(); toast('پیام ثبت شد؛ پیش‌نویس در صف است', 'success'); await renderRoute(); } catch (e) { showError(e); } }); });
    $$('[data-inbox-redraft]').forEach(b => b.addEventListener('click', async () => { try { await api(`/api/inbox/${encodeURIComponent(b.dataset.inboxRedraft)}/draft`, { method: 'POST', body: {} }); toast('پیش‌نویس در صف ساخته می‌شود', 'success'); } catch (e) { showError(e); } }));
    $$('[data-inbox-send]').forEach(b => b.addEventListener('click', async () => { const cardEl = b.closest('[data-inbox-card]'); const reply = cardEl.querySelector('[data-reply-text]').value; if (!reply.trim()) { toast('متن پاسخ خالی است', 'error'); return; } if (!confirmExternal('آیا پاسخ تأییدشده ارسال شود؟ قواعد پنجره و rate limit دوباره در Worker بررسی می‌شوند.')) return; b.disabled = true; try { const result = await api(`/api/inbox/${encodeURIComponent(b.dataset.inboxId)}/send`, { method: 'POST', body: { reply_text: reply, reply_type: b.dataset.inboxSend, confirm: true } }); toast(result.data.manual ? 'اعتبارنامه نیست؛ متن برای ارسال دستی آماده شد' : 'پاسخ ارسال و در لاگ ثبت شد', 'success'); await renderRoute(); } catch (e) { showError(e); b.disabled = false; } }));
    $$('[data-inbox-hide]').forEach(b => b.addEventListener('click', async () => { if (!confirmExternal('وضعیت پنهان‌سازی این کامنت تغییر کند؟')) return; try { await api(`/api/inbox/${encodeURIComponent(b.dataset.inboxHide)}/hide`, { method: 'POST', body: { hide: !b.textContent.includes('آشکار'), confirm: true } }); await renderRoute(); } catch (e) { showError(e); } }));
  });
}

async function analyticsPage() {
  const r = await api('/api/analytics'); const d = r.data; const media = (d.metrics || []).filter(m => m.scope === 'media');
  const byDate = {}; for (const m of media) { const key = m.metric_date; byDate[key] = (byDate[key] || 0) + Number(m.views || 0); }
  const chart = Object.entries(byDate).sort(([a], [b]) => a.localeCompare(b)).slice(-12); const max = Math.max(1, ...chart.map(([, v]) => v));
  const html = `${intro('تحلیل، آمار و آزمایش', 'داده‌های Insights به‌عنوان خلاصه به editorial داده می‌شوند؛ زمان‌بندی بدون داده «داده کافی نیست» است و پیشنهادها فرضیه برای آزمایش‌اند.', '<button class="btn primary" id="insights-pull">به‌روزرسانی Insights</button>')}${d.metrics?.length ? '' : notice('داده کافی نیست. پس از انتشار واقعی و اتصال Instagram Insights، نمودارها و جدول بهترین زمان پر می‌شوند؛ هیچ عددی ساخته نمی‌شود.', 'info')}<div class="grid two" style="margin-top:16px"><div>${card('روند بازدید رسانه‌ها', chart.length ? `<div class="chart">${chart.map(([date, value]) => `<div class="chart-bar"><b>${number(value)}</b><i style="height:${Math.max(3, Math.round(value / max * 135))}px"></i><small>${metricDateLabel(date)}</small></div>`).join('')}</div>` : empty('داده‌ای برای نمودار نیست'))}</div><div>${card('خلاصه تعامل', `<div class="grid two"><div class="metric-card"><div class="metric-label">Reach</div><div class="metric-value">${number(media.reduce((n, m) => n + Number(m.reach || 0), 0))}</div></div><div class="metric-card"><div class="metric-label">Interactions</div><div class="metric-value">${number(media.reduce((n, m) => n + Number(m.interactions || 0), 0))}</div></div><div class="metric-card"><div class="metric-label">Saves</div><div class="metric-value">${number(media.reduce((n, m) => n + Number(m.saves || 0), 0))}</div></div><div class="metric-card"><div class="metric-label">Shares</div><div class="metric-value">${number(media.reduce((n, m) => n + Number(m.shares || 0), 0))}</div></div></div>`)}</div></div><div style="margin-top:16px">${card('جدول بهترین زمان و فرمت (فرضیه‌سازی از داده)', d.best_time?.length ? `<div class="table-wrap"><table><thead><tr><th>فرمت</th><th>ساعت تهران</th><th>تعداد پست</th><th>میانگین Views</th><th>میانگین Reach</th><th>میانگین تعامل</th></tr></thead><tbody>${d.best_time.map(x => `<tr><td>${format(x.format)}</td><td>${x.posted_hour_tehran === null ? '—' : faDigits(x.posted_hour_tehran)}</td><td>${number(x.posts)}</td><td>${number(x.avg_views)}</td><td>${number(x.avg_reach)}</td><td>${number(x.avg_interactions)}</td></tr>`).join('')}</tbody></table></div><p class="small muted">این جدول تضمین الگوریتم نیست؛ برای هر فرضیه آزمایش جدید ثبت کنید.</p>` : empty('داده کافی نیست'))}</div><div style="margin-top:16px">${card('آزمایش‌های تحریریه', `<form id="experiment-form" class="form-grid"><label>عنوان<input name="title" required placeholder="مثلاً: قلاب سؤالی در کروسل"></label><label>متغیر<input name="variable" required placeholder="hook / format / hour"></label><label>فرضیه<input name="hypothesis" required placeholder="فرضیه برای آزمایش..."></label><label>متریک<input name="metric_name" value="saves"></label><div class="form-actions" style="grid-column:1/-1"><button class="btn primary" type="submit">ثبت آزمایش</button></div></form><div class="list" style="margin-top:15px">${(d.experiments || []).map(x => `<div class="list-item"><strong>${escapeHtml(x.title)}</strong><div class="small muted">${escapeHtml(x.variable)} · ${escapeHtml(x.metric_name)} · ${escapeHtml(x.status)}</div><p class="small">${escapeHtml(x.hypothesis)}</p></div>`).join('')}</div>`)}</div>`;
  return page(html, () => { $('#insights-pull')?.addEventListener('click', async event => { event.target.disabled = true; try { const result = await api('/api/insights/pull', { method: 'POST', body: {} }); toast(`Insights ${number(result.data.pulled)} رسانه به‌روزرسانی شد`, 'success'); await renderRoute(); } catch (e) { showError(e); } finally { event.target.disabled = false; } }); $('#experiment-form')?.addEventListener('submit', async event => { event.preventDefault(); try { await api('/api/experiments', { method: 'POST', body: formData(event.target) }); toast('آزمایش ثبت شد', 'success'); await renderRoute(); } catch (e) { showError(e); } }); });
}

function manualPackageView(job) {
  const pack = parse(job.manual_package_json, null); if (!pack) return '';
  return `<details class="list-item"><summary>بسته انتشار دستی ${platformName(job.platform)}</summary><p class="small muted">${escapeHtml(pack.fallback_reason || '')}</p><label>کپشن<textarea readonly>${escapeHtml(pack.caption || '')}</textarea></label><div class="form-actions"><button class="btn ghost small-btn" data-copy-package="${escapeHtml(job.id)}">کپی کپشن</button><button class="btn subtle small-btn" data-download-package="${escapeHtml(job.id)}">دانلود JSON بسته</button><button class="btn primary small-btn" data-mark-published="${escapeHtml(job.id)}">ثبت به‌عنوان منتشرشده + URL</button></div><pre class="json-box">${pretty(pack)}</pre></details>`;
}
async function publishPage() {
  const r = await api('/api/publish'); const jobs = r.data || [];
  const html = `${intro('مرکز انتشار', 'زمان‌بندی، idempotency، polling ویدیو، تلاش مجدد و Manual Package برای هر پلتفرم. retry فقط پس از بررسی وضعیت واقعی انجام دهید.', '<button class="btn ghost" data-route-link="integrations">وضعیت اتصال‌ها</button>')}${jobs.length ? `<div class="stack">${jobs.map(j => `<article class="card"><div class="spread"><div><h3>${escapeHtml(j.title)}</h3><p class="small muted">${platformName(j.platform)} · ${format(j.selected_format)} · ${formatJalali(j.scheduled_at_utc)}</p></div><div class="row">${statusBadge(j.status)}${contentButton(j.content_id, 'محتوا')}</div></div>${j.last_error ? `<div class="notice warn" style="margin:12px 0">${escapeHtml(j.last_error)}</div>` : ''}${j.published_url ? `<p class="small"><strong>URL انتشار:</strong> <a href="${escapeHtml(j.published_url)}" target="_blank" rel="noopener">${escapeHtml(j.published_url)}</a></p>` : ''}${j.container_id ? `<p class="small muted">Container ذخیره‌شده برای جلوگیری از ساخت تکراری: <code>${escapeHtml(j.container_id)}</code></p>` : ''}<div class="form-actions"><button class="btn ghost small-btn" data-publish-retry="${escapeHtml(j.id)}" ${j.status === 'PUBLISHED' ? 'disabled' : ''}>تلاش مجدد</button>${j.status === 'MANUAL_READY' ? `<button class="btn primary small-btn" data-mark-published="${escapeHtml(j.id)}">ثبت انتشار دستی</button>` : ''}</div>${manualPackageView(j)}</article>`).join('')}</div>` : empty('مسیر انتشاری وجود ندارد', 'پس از تأیید گیت ۳ و ساخت تقویم، کارهای هر پلتفرم اینجا ظاهر می‌شوند.')}`;
  const mark = id => { const job = jobs.find(j => j.id === id); openModal('ثبت انتشار دستی', `<form id="mark-published-form" class="stack"><p class="muted small">فقط پس از اینکه پست را واقعاً در پلتفرم دیدید، URL آن را ثبت کنید. این دکمه هیچ ارسال خارجی انجام نمی‌دهد.</p><label>URL واقعی پست (HTTPS)<input name="published_url" type="url" required dir="ltr" placeholder="https://..."></label><div class="form-actions"><button type="button" class="btn ghost" data-close-modal>انصراف</button><button class="btn primary" type="submit">تأیید و ثبت</button></div></form>`); $('#mark-published-form')?.addEventListener('submit', async event => { event.preventDefault(); try { await api(`/api/publish/${encodeURIComponent(id)}/manual-published`, { method: 'POST', body: { ...formData(event.target), confirm: true } }); closeModal(); toast('انتشار دستی ثبت شد', 'success'); await renderRoute(); } catch (e) { showError(e); } }); };
  return page(html, () => {
    $$('[data-publish-retry]').forEach(b => b.addEventListener('click', async () => { if (!confirmExternal('تلاش مجدد انتشار انجام شود؟ اگر نتیجه قبلی نامشخص بود، ابتدا پلتفرم را بررسی کنید.')) return; try { await api(`/api/publish/${encodeURIComponent(b.dataset.publishRetry)}/retry`, { method: 'POST', body: {} }); toast('کار انتشار دوباره در صف قرار گرفت', 'success'); await renderRoute(); } catch (e) { showError(e); } }));
    $$('[data-mark-published]').forEach(b => b.addEventListener('click', () => mark(b.dataset.markPublished)));
    $$('[data-copy-package]').forEach(b => b.addEventListener('click', () => { const job = jobs.find(j => j.id === b.dataset.copyPackage); copy(parse(job.manual_package_json, {})?.caption || ''); }));
    $$('[data-download-package]').forEach(b => b.addEventListener('click', () => { const job = jobs.find(j => j.id === b.dataset.downloadPackage); downloadText(JSON.stringify(parse(job.manual_package_json, {}), null, 2), `nasra-${job.platform}-${job.id}.json`, 'application/json'); }));
    $$('[data-route-link]').forEach(b => b.addEventListener('click', () => navigate(b.dataset.routeLink)));
  });
}

async function integrationsPage() {
  const r = await api('/api/integrations'); const d = r.data; const configured = d.configured || {};
  const status = (key, label) => `<div class="status-row"><code>${label}</code>${configured[key] ? badge('configured', 'ok') : badge('not configured', 'warn')}</div>`;
  const html = `${intro('یکپارچه‌سازی‌ها و اعتبارنامه‌ها', 'Secrets فقط در Cloudflare Secrets هستند. این صفحه فقط حضور/عدم حضور و وضعیت را نشان می‌دهد، نه مقدار محرمانه.', '<button class="btn ghost" data-route-link="settings">تنظیم کانال‌ها</button>')}<div class="grid two"><div>${card('Secrets و binding', `<div class="status-grid">${Object.keys(configured).map(k => status(k, k)).join('')}</div><p class="small muted">در صورت نبود هر Secret، سرویس مربوط «not configured» می‌شود و بقیه سیستم و Manual Mode کار می‌کند.</p>`)}</div><div>${card('Instagram Graph API', `<div class="row">${badge(d.instagram?.token_status || 'not_configured', d.instagram?.token_status === 'active' ? 'ok' : 'warn')}${badge(d.instagram?.auth_mode || 'instagram', 'info')}</div><p class="small">نسخه API: <code>${escapeHtml(d.instagram?.api_version || 'v26.0')}</code><br>انقضای توکن: ${d.instagram?.token_expires_at ? formatJalali(d.instagram.token_expires_at) : 'نامشخص/ثبت نشده'}<br>آخرین تازه‌سازی: ${d.instagram?.last_refreshed_at ? formatJalali(d.instagram.last_refreshed_at) : '—'}<br>آخرین Pull موفق: ${d.instagram?.last_successful_pull?.at ? formatJalali(d.instagram.last_successful_pull.at) : '—'}</p>${d.instagram?.last_error ? `<div class="notice danger">${escapeHtml(d.instagram.last_error)}</div>` : ''}<div class="form-actions"><button class="btn subtle" data-test-platform="instagram">تست اتصال</button><button class="btn ghost" id="refresh-ig">تازه‌سازی توکن</button></div>`)}</div></div><div class="grid two" style="margin-top:16px"><div>${card('Webhook اینستاگرام', `<label>Callback URL<input readonly dir="ltr" value="${escapeHtml(d.instagram_webhooks?.url || '')}"></label><div class="form-actions"><button class="btn ghost small-btn" data-copy-value="${escapeHtml(d.instagram_webhooks?.url || '')}">کپی URL</button></div><p class="small">GET verification با IG_VERIFY_TOKEN و POST با X-Hub-Signature-256 و IG_APP_SECRET. رویدادها dedupe و در background پردازش می‌شوند.</p><a href="https://developers.facebook.com/documentation/instagram-platform/webhooks" target="_blank" rel="noopener" class="small">مستندات رسمی Webhooks</a>`)}</div><div>${card('Telegram و Rubika', `<p class="small">Telegram owner webhook:<br><code>${escapeHtml(d.telegram?.webhook_url || '')}</code></p><div class="form-actions"><button class="btn ghost small-btn" data-copy-value="${escapeHtml(d.telegram?.webhook_url || '')}">کپی Telegram URL</button><button class="btn primary small-btn" id="setup-telegram-webhook">ثبت Webhook از Worker</button><button class="btn subtle small-btn" data-test-platform="telegram">تست بات تلگرام</button><button class="btn subtle small-btn" data-test-platform="rubika">تست بات روبیکا</button></div><div class="notice ${d.rubika?.channel_id_present ? 'ok' : 'warn'}">Rubika channel: ${d.rubika?.channel_id_present ? 'configured' : 'not configured'}<br>آلبوم بومی: <strong>needs verification</strong>؛ بسته دستی جایگزین امن است.</div>`)}</div></div><div style="margin-top:16px">${card('مستندات مرجع و آماده‌سازی', `<div class="list"><div class="list-item"><strong>Meta Instagram Login / Facebook Login</strong><p class="small">هر دو مسیر توکن در راهنما مستند شده‌اند. مسیر پیش‌فرض را در Settings انتخاب کنید؛ حساب Business/Creator و permissionهای لازم برای App Review جدا هستند.</p><a href="https://developers.facebook.com/documentation/instagram-platform/instagram-graph-api" target="_blank" rel="noopener" class="small">Instagram Platform رسمی</a></div><div class="list-item"><strong>Rubika Bot API v3</strong><p class="small">فقط botapi.rubika.ir/v3 و متدهای رسمی؛ هیچ session-login یا scraping استفاده نمی‌شود.</p><a href="https://rubika.ir/botapi/methods" target="_blank" rel="noopener" class="small">rubika.ir/botapi/methods</a></div></div>`)}</div>`;
  return page(html, () => {
    $$('[data-copy-value]').forEach(b => b.addEventListener('click', () => copy(b.dataset.copyValue)));
    $('#setup-telegram-webhook')?.addEventListener('click', async () => { if (!window.confirm('Webhook تلگرام به همین Worker و با TG_SECRET ثبت شود؟')) return; try { await api('/api/integrations/telegram/webhook', { method: 'POST', body: {} }); toast('Webhook تلگرام ثبت شد', 'success'); } catch (e) { showError(e); } });
    $$('[data-test-platform]').forEach(b => b.addEventListener('click', async () => { b.disabled = true; try { const result = await api('/api/integrations/test', { method: 'POST', body: { platform: b.dataset.testPlatform } }); toast(`اتصال موفق: ${result.data.username || result.data.id || 'OK'}`, 'success'); } catch (e) { showError(e); } finally { b.disabled = false; } }));
    $('#refresh-ig')?.addEventListener('click', async () => { if (!window.confirm('تازه‌سازی توکن طبق مسیر رسمی انجام شود؟')) return; try { const result = await api('/api/integrations/refresh', { method: 'POST', body: {} }); toast(result.data.refreshed ? 'توکن تازه و رمزنگاری ذخیره شد' : `تازه‌سازی لازم نیست: ${result.data.reason || ''}`, 'success'); await renderRoute(); } catch (e) { showError(e); } });
    $$('[data-route-link]').forEach(b => b.addEventListener('click', () => navigate(b.dataset.routeLink)));
  });
}

async function settingsPage() {
  const [r, health] = await Promise.all([api('/api/settings'), api('/api/health')]); const d = r.data || {};
  const html = `${intro('تنظیمات و سلامت', 'تنظیمات غیرمحرمانه در D1 ذخیره می‌شوند. Secrets را هرگز در این فرم یا Playbook وارد نکنید.', '<button class="btn ghost" id="settings-health">بررسی سلامت</button>')}<div class="grid two"><div>${card('کانال‌ها، مسیر توکن و سهمیه', `<form id="settings-form" class="stack"><label>عنوان استودیو<input name="studio_title" value="${escapeHtml(d.studio_title || '')}"></label><label>Chat ID کانال تلگرام (غیرمحرمانه)<input name="tg_channel_id" dir="ltr" value="${escapeHtml(d.tg_channel_id || '')}" placeholder="@nasra_channel یا -100..."></label><label>Chat ID کانال روبیکا<input name="rubika_channel_id" dir="ltr" value="${escapeHtml(d.rubika_channel_id || '')}"></label><label>مسیر Instagram Login<select name="ig_auth_mode"><option value="instagram">Instagram Login — graph.instagram.com</option><option value="facebook">Facebook Login — graph.facebook.com</option><option value="auto">Auto (پیش‌فرض امن: Instagram)</option></select></label><label>نسخه Graph API<input name="ig_api_version" dir="ltr" value="${escapeHtml(d.ig_api_version || 'v26.0')}"></label><div class="form-grid"><label>سقف توکن روزانه کل<input name="global_daily_token_cap" type="number" value="${d.global_daily_token_cap || 150000}"></label><label>سقف درخواست روزانه کل<input name="global_daily_request_cap" type="number" value="${d.global_daily_request_cap || 250}"></label></div><div class="form-grid"><label>تعداد snapshotهای Sheets<input name="backup_keep_snapshots" type="number" min="1" max="60" value="${d.backup_keep_snapshots || 14}"></label><label>ساعت‌های پیش‌فرض (با ویرگول)<input name="posting_hours" dir="ltr" value="${(d.default_posting_hours || []).join(',')}"></label></div><label class="check-label"><input type="checkbox" name="carousel_strict_no_mixed" ${d.carousel_strict_no_mixed !== false ? 'checked' : ''}> قانون سخت‌گیرانه عدم ترکیب عکس/ویدیو در کروسل</label><label class="check-label"><input type="checkbox" name="r2_enabled" ${d.r2_enabled ? 'checked' : ''}> فعال‌سازی اختیاری R2 (نیازمند binding و ممکن است روش پرداخت بخواهد)</label><label>R2 public base URL (اختیاری)<input name="r2_public_base_url" dir="ltr" value="${escapeHtml(d.r2_public_base_url || '')}" placeholder="https://pub-....r2.dev"></label><div class="form-actions"><button class="btn primary" type="submit">ذخیره تنظیمات</button></div></form>`)}</div><div>${card('Health و قراردادهای امنیتی', `<div id="health-result"><div class="status-row"><span>Worker / D1</span>${health.ok ? badge('healthy', 'ok') : badge('error', 'danger')}</div><p class="small">زمان سرور: ${formatJalali(health.time)}<br>تاریخ جلالی سرور: ${faDigits(health.jalali?.date || '')}<br>نسخه: ${escapeHtml(health.version || '')}</p></div><div class="notice info">ورود با HMAC-signed HttpOnly cookie، CSRF، rate limit و CSP انجام می‌شود. Webhookهای Telegram/Instagram مسیر مستقل و احرازشده دارند.</div><div class="notice warn">برای استفاده واقعی، Secretهای OWNER_PASSWORD و SESSION_SECRET قوی بسازید. SESSION_SECRET کلید رمزنگاری توکن refresh‌شده نیز هست؛ آن را نچرخانید مگر اینکه توکن را دوباره وارد کنید.</div>`)}</div></div>`;
  return page(html, () => { const form = $('#settings-form'); form.ig_auth_mode.value = d.ig_auth_mode || 'instagram'; form.addEventListener('submit', async event => { event.preventDefault(); const data = formData(form); data.carousel_strict_no_mixed = form.carousel_strict_no_mixed.checked; data.r2_enabled = form.r2_enabled.checked; data.default_posting_hours = data.posting_hours.split(',').map(x => x.trim()).filter(Boolean); delete data.posting_hours; try { await api('/api/settings', { method: 'PUT', body: data }); toast('تنظیمات ذخیره شد', 'success'); } catch (e) { showError(e); } }); $('#settings-health')?.addEventListener('click', async () => { try { const h = await api('/api/health'); $('#health-result').innerHTML = `<div class="notice ok">سلامت بررسی شد: ${formatJalali(h.time)} · D1 ${h.db ? 'متصل' : 'قطع'}</div>`; } catch (e) { showError(e); } }); });
}


/*
 * Autopilot control. The policy lives in studio_settings and is read by the
 * runtime on every tick, so saving here changes behaviour immediately without a
 * restart. Nothing on this page publishes: it decides what the machine may do on
 * its own, and shows what it actually did.
 */
async function autopilotPage() {
  const [statusResult, guardResult] = await Promise.all([
    api('/api/ops/autopilot').catch(e => ({ data: null, error: e })),
    api('/api/ops/guard').catch(() => ({ data: null }))
  ]);
  const s = statusResult.data || {};
  const p = s.policy || { policy: 'off', enabled: false, platforms: ['telegram'], daily_slots: ['09:00', '21:00'], max_new_per_day: 2, require_source: true };
  const guard = guardResult.data || {};
  const policyLabels = { off: 'خاموش', assisted: 'دستیار (بدون تأیید خودکار)', auto_gates: 'خودکار تا انتشار', full_auto: 'کاملاً خودکار' };
  const platforms = ['telegram', 'rubika', 'instagram'];
  const image = s.image_provider || {};
  const media = s.media_store || {};
  const ticks = Number(s.ticks || 0);
  const html = `${intro('اتوپایلوت', 'اینجا تعیین می‌کنید ماشین تا کجا اجازهٔ تصمیم دارد. هیچ‌چیز بدون سیاستِ روشن و بدون فیلترهای ایمنی منتشر نمی‌شود.', '<button class="btn ghost" id="ap-refresh">↻ تازه‌سازی</button><button class="btn subtle" id="ap-tick">اجرای یک چرخه</button>')}
    <div class="grid four">
      <div class="card metric-card"><span class="metric-icon">⚙</span><div class="metric-label">سیاست فعال</div><div class="metric-value" style="font-size:17px">${escapeHtml(policyLabels[p.policy] || p.policy)}</div><div class="metric-note">${p.enabled ? 'فعال' : 'غیرفعال'}</div></div>
      <div class="card metric-card"><span class="metric-icon">▦</span><div class="metric-label">کارهای در جریان</div><div class="metric-value">${number(s.content_in_flight)}</div><div class="metric-note">${number(s.pending_gates)} گیت در انتظار</div></div>
      <div class="card metric-card"><span class="metric-icon">◷</span><div class="metric-label">انتشار زمان‌بندی‌شده</div><div class="metric-value">${number(s.scheduled_jobs)}</div><div class="metric-note">۲۴ ساعت گذشته: ${number(s.published_last_24h)}</div></div>
      <div class="card metric-card"><span class="metric-icon">◌</span><div class="metric-label">چرخه‌های اجراشده</div><div class="metric-value">${number(ticks)}</div><div class="metric-note">${s.last_tick_at ? escapeHtml(relativeTime(s.last_tick_at)) : 'هنوز اجرا نشده'}</div></div>
    </div>
    <div class="grid two" style="margin-top:16px"><div>
    ${card('سیاست اجرا', `<form id="ap-form" class="stack">
      <label>سطح خودکاری<select name="policy">${Object.entries(policyLabels).map(([key, label]) => `<option value="${key}" ${p.policy === key ? 'selected' : ''}>${escapeHtml(label)}</option>`).join('')}</select><span class="help">«دستیار» فقط محتوا و پوستر می‌سازد و هیچ گیتی را تأیید نمی‌کند — یعنی هر سه گیت دست خود شماست و ماشین تا گیت ۱ می‌رود و می‌ایستد. «خودکار تا انتشار» گیت‌ها را فقط وقتی تأیید می‌کند که همهٔ بررسی‌ها تمیز باشند.</span></label>
      <label class="check-label"><input type="checkbox" name="enabled" ${p.enabled ? 'checked' : ''}> اتوپایلوت فعال باشد</label>
      <div>پلتفرم‌های هدف<div class="grid three" style="margin-top:6px">${platforms.map(x => `<label class="check-label"><input type="checkbox" name="platform_${x}" ${(p.platforms || []).includes(x) ? 'checked' : ''}> ${escapeHtml(platformName(x))}</label>`).join('')}</div></div>
      <div class="form-grid"><label>ساعت‌های ساخت محتوا (با ویرگول)<input name="daily_slots" dir="ltr" value="${escapeHtml((p.daily_slots || []).join(','))}" placeholder="09:00,21:00"></label><label>حداکثر محتوای تازه در روز<input name="max_new_per_day" type="number" min="0" max="10" value="${Number(p.max_new_per_day ?? 2)}"></label></div>
      <label class="check-label"><input type="checkbox" name="require_source" ${p.require_source !== false ? 'checked' : ''}> بدون منبع تأییدشده و راستی‌آزمایی pass، گیت ۳ به‌طور خودکار تأیید نشود</label>
      <div class="form-actions"><button class="btn primary" type="submit">ذخیرهٔ سیاست</button></div>
    </form>`)}
    ${card('قواعدی که همیشه اعمال می‌شوند', `<ul class="small" style="line-height:2;padding-right:18px">
      <li>هر <b>risk_flag</b> یا <b>needs_info</b> در ایده، محتوا را به شما برمی‌گرداند.</li>
      <li>راستی‌آزمایی باید <b>pass</b> باشد و حداقل یک ادعای <b>تأییدشده</b> داشته باشد؛ نتیجهٔ pass بدون هیچ منبع کافی نیست.</li>
      <li>گیت ۳ فقط با <b>بررسی فنی بدون خطا</b> و <b>رسانهٔ پیوست‌شده</b> تأیید می‌شود.</li>
      <li>هر تأیید خودکار با نام <code>system:autopilot</code> در لاگ حسابرسی ثبت می‌شود.</li>
      <li>حالت <b>${escapeHtml(guard.mode === 'live' ? 'live' : 'dry_run')}</b> شیر اطمینان انتشار: ${guard.mode === 'live' ? 'ارسال واقعی فقط برای مقصدهای مجاز و با تأیید.' : 'هیچ ارسال واقعی از این پروسه خارج نمی‌شود.'}</li>
    </ul>`)}
    </div><div>
    ${card('تولید رسانه', `<div class="status-grid">
      <div class="status-row"><span>مدل تصویر</span>${image.configured ? badge('آماده', 'ok') : badge('تنظیم نشده', 'warn')}</div>
      <div class="status-row"><span>مدل فعال</span><code>${escapeHtml(image.working_model || '—')}</code></div>
      <div class="status-row"><span>تصاویر ساخته‌شده</span><strong>${number(image.stats?.images)}</strong></div>
      <div class="status-row"><span>خطاهای اخیر</span><strong>${number(image.stats?.failures)}</strong></div>
      <div class="status-row"><span>پوشهٔ رسانه</span>${media.configured ? badge('قابل دانلود', 'ok') : badge('PUBLIC_BASE_URL ندارد', 'warn')}</div>
      <div class="status-row"><span>فایل‌های ذخیره‌شده</span><strong>${number(media.files)}</strong></div>
    </div>${image.configured ? '' : notice('برای تولید خودکار پوستر، IMAGE_PROVIDER=gemini و IMAGE_API_KEY را در فایل .env اضافه کنید. تا آن زمان مسیر دستی «دانلود JPEG» در صفحهٔ محتوا کار می‌کند.', 'info')}${media.configured ? '' : notice('PUBLIC_BASE_URL خالی است؛ لینک رسانهٔ محلی برای تلگرام/اینستاگرام قابل دانلود نیست. آدرس تونل یا دامنه را در .env قرار دهید.', 'warn')}
      <div class="form-actions"><button class="btn ghost small-btn" id="ap-media">مشاهدهٔ فایل‌های رسانه</button><button class="btn ghost small-btn" id="ap-prune">پاک‌سازی فایل‌های قدیمی</button></div>`)}
    ${card('آخرین چرخه', `<pre class="json-box">${escapeHtml(JSON.stringify(s.last_summary || { message: 'هنوز اجرا نشده است' }, null, 2))}</pre>${s.last_error ? notice(`آخرین خطا: ${s.last_error.message}`, 'danger') : ''}`)}
    </div></div>`;
  return page(html, () => {
    $('#ap-refresh')?.addEventListener('click', renderRoute);
    $('#ap-tick')?.addEventListener('click', async event => {
      event.target.disabled = true;
      try { const r = await api('/api/ops/autopilot/tick', { method: 'POST', body: {} }); toast(`چرخه اجرا شد: ${number(r.data?.created)} محتوا، ${number(r.data?.approved)} تأیید`, 'success'); await renderRoute(); }
      catch (e) { showError(e); } finally { event.target.disabled = false; }
    });
    const form = $('#ap-form');
    form?.addEventListener('submit', async event => {
      event.preventDefault();
      const selectedPlatforms = platforms.filter(x => form[`platform_${x}`]?.checked);
      if (!selectedPlatforms.length) { toast('حداقل یک پلتفرم انتخاب کنید', 'error'); return; }
      const payload = {
        policy: form.policy.value,
        enabled: form.enabled.checked,
        platforms: selectedPlatforms,
        daily_slots: String(form.daily_slots.value || '').split(',').map(x => x.trim()).filter(Boolean),
        max_new_per_day: Number(form.max_new_per_day.value || 0),
        require_source: form.require_source.checked
      };
      if (payload.policy !== 'off' && !window.confirm(`سیاست «${policyLabels[payload.policy]}» ذخیره شود؟ ${payload.policy === 'off' ? '' : 'از این پس ماشین طبق همین قاعده تصمیم می‌گیرد.'}`)) return;
      try { await api('/api/ops/autopilot', { method: 'PUT', body: payload }); toast('سیاست ذخیره شد', 'success'); await renderRoute(); }
      catch (e) { showError(e); }
    });
    $('#ap-media')?.addEventListener('click', async () => {
      try {
        const r = await api('/api/ops/media');
        const files = r.data?.files || [];
        openModal('فایل‌های رسانه', files.length ? `<div class="list">${files.map(f => `<div class="list-item spread"><a href="${escapeHtml(f.url)}" target="_blank" rel="noopener" class="truncate">${escapeHtml(f.name)}</a><span class="small muted">${number(Math.round(f.bytes / 1024))} KB</span></div>`).join('')}</div>` : empty('فایلی ذخیره نشده است'));
      } catch (e) { showError(e); }
    });
    $('#ap-prune')?.addEventListener('click', async () => {
      if (!window.confirm('فایل‌های رسانهٔ قدیمی پاک شوند؟ فایل‌هایی که در محتوای منتشرنشده استفاده شده‌اند باید دستی بررسی شوند.')) return;
      try { const r = await api('/api/ops/media/prune', { method: 'POST', body: {} }); toast(`${number(r.data?.removed)} فایل پاک شد`, 'success'); await renderRoute(); }
      catch (e) { showError(e); }
    });
  });
}

async function logsPage() {
  const r = await api('/api/logs'); const logs = r.data || [];
  const html = `${intro('لاگ و حسابرسی', 'هر تأیید، تغییر پرامپت، انتشار، خطا و بازیابی در Audit Log ثبت می‌شود. IP فقط به شکل hash و Secrets هرگز ثبت نمی‌شوند.', '<button class="btn ghost" id="logs-refresh">↻</button>')}${logs.length ? `<div class="table-wrap"><table><thead><tr><th>زمان</th><th>کننده</th><th>عمل</th><th>موجودیت</th><th>جزئیات امن</th></tr></thead><tbody>${logs.map(l => `<tr><td>${formatJalali(l.created_at)}</td><td>${escapeHtml(l.actor)}</td><td>${badge(l.action, l.action.includes('failed') || l.action.includes('error') ? 'danger' : 'info')}</td><td>${escapeHtml(l.entity_type)}<br><code>${escapeHtml(l.entity_id || '')}</code></td><td><pre style="max-width:360px;max-height:150px;margin:0">${pretty(parse(l.details_json, {}))}</pre></td></tr>`).join('')}</tbody></table></div>` : empty('لاگی وجود ندارد')}`;
  return page(html, () => $('#logs-refresh')?.addEventListener('click', renderRoute));
}

async function backupPage() {
  const r = await api('/api/backup'); const snapshots = r.data || []; const last = r.last;
  const html = `${intro('پشتیبان‌گیری و بازیابی', 'هر شب Worker به Apps Script می‌نویسد؛ تاریخ/ساعت/ID با فرمت TEXT (@) پیش از setValues حفظ می‌شوند. Mirrorها هیچ ردیفی را حذف نمی‌کنند.', '<button class="btn primary" id="backup-export">دانلود JSON کامل</button>')}<div class="grid two"><div>${card('Google Sheets / Apps Script', `<p class="small">آخرین وضعیت: ${last ? `${last.status} · ${formatJalali(last.at)} · ${number(last.rows)} ردیف` : 'هنوز پشتیبان موفق ثبت نشده است'}</p><div class="notice info">GAS_URL و GAS_KEY در Secrets قرار می‌گیرند. در Sheets، ستون‌های scheduled_jalali و created_at به‌صورت متن باقی می‌مانند؛ «21:00» و «1405/07/23» به عدد تبدیل نمی‌شوند.</div><div class="form-actions"><button class="btn primary" id="backup-run">اجرای پشتیبان‌گیری Sheets</button></div>`)}</div><div>${card('بازیابی از JSON', `<form id="restore-form" class="stack"><label>فایل پشتیبان JSON<input name="file" type="file" accept="application/json,.json" required></label><p class="help">Restore فقط upsert انجام می‌دهد و داده‌های موجود را حذف نمی‌کند. Secrets و Sessionها در فایل نیستند.</p><button class="btn warn" type="submit">بازیابی و upsert</button></form>`)}</div></div><div style="margin-top:16px">${card('Snapshotهای ثبت‌شده', snapshots.length ? `<div class="table-wrap"><table><thead><tr><th>زمان</th><th>مقصد</th><th>وضعیت</th><th>ردیف</th><th>خطا</th></tr></thead><tbody>${snapshots.map(s => `<tr><td>${formatJalali(s.created_at)}<br>${faDigits(s.jalali_date)} ${faDigits(s.tehran_time)}</td><td>${escapeHtml(s.destination)}</td><td>${statusBadge(s.status)}</td><td>${number(s.rows_exported)}</td><td>${escapeHtml(s.error_message || '—')}</td></tr>`).join('')}</tbody></table></div>` : empty('Snapshotی ثبت نشده است'))}</div>`;
  return page(html, () => { $('#backup-export')?.addEventListener('click', async () => { try { downloadBlob(await apiBlob('/api/backup/export'), `nasra-backup-${todayJalali().date.replaceAll('/', '-')}.json`); toast('فایل پشتیبان دانلود شد', 'success'); } catch (e) { showError(e); } }); $('#backup-run')?.addEventListener('click', async event => { event.target.disabled = true; try { await api('/api/backup/run', { method: 'POST', body: {} }); toast('پشتیبان Sheets انجام شد', 'success'); await renderRoute(); } catch (e) { showError(e); } finally { event.target.disabled = false; } }); $('#restore-form')?.addEventListener('submit', async event => { event.preventDefault(); const file = event.target.file.files[0]; if (!file) return; if (!window.confirm('بازیابی فایل انجام شود؟ داده‌های موجود حذف نمی‌شوند اما ردیف‌های هم‌کلید به‌روزرسانی می‌شوند.')) return; try { const data = JSON.parse(await file.text()); let cursor = null; let total = 0; let done = false; while (!done) { const result = await api('/api/backup/restore', { method: 'POST', body: { ...data, restore_cursor: cursor } }); total += Number(result.data.restored || 0); done = result.data.done === true; cursor = result.data.next_cursor; if (!done && !cursor) throw new Error('اشکال در ادامه بازیابی'); } toast(`${number(total)} ردیف بازیابی شد`, 'success'); } catch (e) { showError(e); } }); });
}

async function selftestPage() {
  const html = `${intro('آزمون پذیرش سرتاسری', 'تست‌ها با ID جدا و بدون شبکه خارجی اجرا می‌شوند؛ برای رعایت سقف ۵۰ کوئری D1 در هر invocation، UI پنج بخش را پشت‌سرهم اجرا می‌کند.', '<button class="btn primary" id="run-selftest">اجرای همه تست‌ها</button>')}<div id="selftest-result">${notice('برای شروع روی «اجرای همه تست‌ها» بزنید. خروجی باید ۱۶/۱۶ سبز باشد؛ تست‌ها هیچ پست یا پیام واقعی ارسال نمی‌کنند.', 'info')}</div>`;
  return page(html, () => $('#run-selftest')?.addEventListener('click', async event => {
    event.target.disabled = true;
    const output = $('#selftest-result');
    try {
      const tests = []; let passed = 0; let checkedAt = '';
      for (const part of ['p1', 'p2', 'p3', 'p4', 'p5']) {
        output.innerHTML = `<div class="empty">در حال اجرای بخش ${faDigits(part.slice(1))} از ۴…</div>`;
        const result = await api(`/api/selftest?part=${part}`);
        tests.push(...result.tests); passed += result.passed; checkedAt = result.checked_at;
      }
      const ok = passed === tests.length;
      output.innerHTML = `<div class="notice ${ok ? 'ok' : 'danger'}"><strong>${ok ? 'همه تست‌ها قبول شدند' : 'برخی تست‌ها قبول نشدند'}: ${faDigits(passed)} / ${faDigits(tests.length)}</strong><br>شبکه خارجی: ندارد · پنج invocation کوچک · زمان: ${formatJalali(checkedAt)}</div><div class="table-wrap" style="margin-top:15px"><table><thead><tr><th>نتیجه</th><th>تست پذیرش</th><th>جزئیات</th></tr></thead><tbody>${tests.map(t => `<tr><td>${t.ok ? badge('PASS', 'ok') : badge('FAIL', 'danger')}</td><td>${escapeHtml(t.name)}</td><td><pre style="max-width:420px;max-height:130px;margin:0">${pretty(t.details)}</pre></td></tr>`).join('')}</tbody></table></div>`;
    } catch (e) { output.innerHTML = `<div class="notice danger">${escapeHtml(errorText(e))}</div>`; }
    finally { event.target.disabled = false; }
  }));
}

export async function renderPageRoute(route) {
  if (route.name === 'dashboard') return dashboardPage();
  if (route.name === 'approvals') return approvalsPage();
  if (route.name === 'pipeline') return pipelinePage();
  if (route.name === 'content' && route.id) return contentPage(route.id);
  if (route.name === 'calendar') return calendarPage();
  if (route.name === 'sources') return sourcesPage();
  if (route.name === 'playbook') return playbookPage();
  if (route.name === 'agents') return agentsPage();
  if (route.name === 'inbox') return inboxPage();
  if (route.name === 'analytics') return analyticsPage();
  if (route.name === 'publish') return publishPage();
  if (route.name === 'integrations') return integrationsPage();
  if (route.name === 'settings') return settingsPage();
  if (route.name === 'autopilot') return autopilotPage();
  if (route.name === 'logs') return logsPage();
  if (route.name === 'backup') return backupPage();
  if (route.name === 'selftest') return selftestPage();
  return dashboardPage();
}
